"""Dépendance à un même pays et impact des références partagées."""
from pathlib import Path
import unittest

import pandas as pd

from plm.business import cost_lines, criticality, load_business
from plm.dependencies import UNKNOWN_COUNTRY, component_usage, country_components, country_summary
from plm.impact import set_link_quantity
from plm.model import build_model
from plm.parser import parse_xpdmxml
from test_features import simple_xml

ROOT = Path(__file__).resolve().parents[1]


class DependencyTests(unittest.TestCase):
    def setUp(self):
        # Une deuxième pièce Q dans A ; P reste partagée par A et C.
        xml = simple_xml().replace(b'</ProductStructure>',
            b'<Product id="Q"><ID>prd-Q</ID><Name>Q</Name></Product>'
            b'<ProductInst id="AQ"><ID>AQ</ID><Owned>A</Owned><Instancing>Q</Instancing></ProductInst>'
            b'</ProductStructure>')
        self.model = build_model(parse_xpdmxml(xml))
        self.lines = pd.DataFrame([
            dict(xml_id='P', line_type='Composant', country='États-Unis', supplier='S1',
                 purchase_line=140.0, country_risk=2),
            dict(xml_id='Q', line_type='Composant', country='États-Unis', supplier='S2',
                 purchase_line=60.0, country_risk=2),
            dict(xml_id='R', line_type='Assemblage', country='France', supplier='Interne',
                 purchase_line=0.0, country_risk=1),
        ])

    def test_usage_distinguishes_local_instances_and_product_quantities(self):
        usage = component_usage(self.model).set_index('xml_id')
        self.assertNotIn('R', usage.index)
        self.assertEqual(usage.loc['P', 'direct_parents'], 2)
        self.assertEqual(usage.loc['P', 'ancestors'], 4)
        self.assertEqual(usage.loc['P', 'link_instances'], 5)
        self.assertEqual(usage.loc['P', 'total_qty'], 14)
        updated = component_usage(set_link_quantity(self.model, 'A', 'P', 5)).set_index('xml_id')
        self.assertEqual(updated.loc['P', 'link_instances'], 7)
        self.assertEqual(updated.loc['P', 'total_qty'], 18)
        self.assertEqual(updated.loc['P', 'ancestors'], 4)

    def test_same_country_different_suppliers_and_parent_deduplication(self):
        parts = country_components(self.model, self.lines)
        summary = country_summary(parts)
        self.assertEqual(len(summary), 1)
        row = summary.iloc[0]
        self.assertEqual(row.country, 'États-Unis')
        self.assertEqual(row.references, 2)
        self.assertEqual(row.instances, 16)
        self.assertEqual(row.direct_parents, 2)
        self.assertEqual(row.ancestors, 4)
        self.assertEqual(row.purchase_line, 200)
        self.assertEqual(row.purchase_share, 100)
        self.assertEqual(row.components, 'P · Q')
        self.assertEqual(row.shared_risk, 'Exposition commune')

    def test_missing_country_is_visible_without_inferred_origin(self):
        lines = self.lines[self.lines.xml_id != 'Q']
        parts = country_components(self.model, lines)
        summary = country_summary(parts).set_index('country')
        self.assertEqual(summary.loc[UNKNOWN_COUNTRY, 'references'], 1)
        self.assertEqual(summary.loc[UNKNOWN_COUNTRY, 'reference_share'], 50)
        self.assertTrue(pd.isna(summary.loc[UNKNOWN_COUNTRY, 'purchase_line']))
        self.assertEqual(summary.loc['États-Unis', 'purchase_share'], 100)
        self.lines.loc[self.lines.xml_id == 'Q', 'country'] = '  '
        blank = country_components(self.model, self.lines).set_index('xml_id')
        self.assertEqual(blank.loc['Q', 'country'], UNKNOWN_COUNTRY)

    def test_unmapped_product_and_excluded_geometry(self):
        business = load_business(ROOT / 'data/business')
        summary = country_summary(country_components(self.model, cost_lines(self.model, business)))
        self.assertEqual(summary.iloc[0].country, UNKNOWN_COUNTRY)
        self.assertEqual(summary.iloc[0].references, 2)
        self.assertTrue(pd.isna(summary.iloc[0].purchase_share))
        self.lines.loc[self.lines.xml_id == 'Q', 'line_type'] = 'Exclu'
        self.assertEqual(list(country_components(self.model, self.lines).xml_id), ['P'])

    def test_criticality_depends_on_country_not_supplier_split(self):
        business = load_business(ROOT / 'data/business')
        model = build_model(parse_xpdmxml(ROOT / 'data/XPDMXML_ECAR_PLM.xml'))
        lines = cost_lines(model, business)
        before = criticality(lines, business).set_index('xml_id')
        lines.loc[lines.line_type == 'Composant', 'supplier_id'] = 'same-supplier'
        after = criticality(lines, business).set_index('xml_id')
        pd.testing.assert_series_equal(before['Concentration pays'], after['Concentration pays'])
        countries = lines[lines.line_type == 'Composant'].groupby('country').line_cost.sum()
        self.assertTrue((before[before.country == countries.idxmax()]['Concentration pays'] == 10).all())
        self.assertTrue(before.criticality.between(0, 100).all())


if __name__ == '__main__':
    unittest.main()
