"""Régressions métier : instances partagées, propagation, XML et scénarios."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

from defusedxml.common import DefusedXmlException

from plm.business import CU, Scenario, cost_lines, load_business
from plm.impact import change_impact, set_link_quantity
from plm.market import forecast
from plm.model import build_model
from plm.parser import NS, parse_xpdmxml
from views.tree import unit_rollup

ROOT = Path(__file__).resolve().parents[1]


def simple_xml():
    # Deux chemins, de longueurs différentes, vers P : R-A-P et R-B-C-P.
    products = ''.join(f'<Product id="{n}"><ID>prd-{n}</ID><Name>{n}</Name>'
                       '<WCGEquivalentComputedExt.V_WCG_Mass>1</WCGEquivalentComputedExt.V_WCG_Mass>'
                       '</Product>' for n in ['R', 'A', 'B', 'C', 'P'])
    links = []
    for parent, child, qty in [('R', 'A', 2), ('R', 'B', 1), ('A', 'P', 3), ('B', 'C', 4), ('C', 'P', 2)]:
        for i in range(qty):
            links.append(f'<ProductInst id="{parent}{child}{i}"><ID>{parent}{child}{i}</ID>'
                         f'<Owned>{parent}</Owned><Instancing>{child}</Instancing></ProductInst>')
    return (f'<XPDMXML xmlns="{NS["x"]}"><ProductStructure rootRefs="R">'
            + products + ''.join(links) + '</ProductStructure></XPDMXML>').encode()


class FeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = build_model(parse_xpdmxml(ROOT / 'data/XPDMXML_ECAR_PLM.xml'))
        cls.business = load_business(ROOT / 'data/business')

    def test_shared_instances_and_depth(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        self.assertEqual(model.comp('P').total_qty, 14)
        self.assertEqual((model.comp('P').level, model.comp('P').max_level), (2, 3))
        impact = change_impact(model, 'P').set_index('xml_id')
        self.assertEqual(impact.loc['R', 'instances'], 14)
        self.assertEqual((impact.loc['R', 'depth_min'], impact.loc['R', 'depth_max']), (2, 3))
        self.assertEqual(model.quantities_under('A')['P'], 3)

    def test_quantity_edit_round_trip_and_original_unchanged(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        updated = set_link_quantity(model, 'A', 'P', 5)
        self.assertEqual(updated.comp('P').total_qty, 18)
        self.assertEqual(model.comp('P').total_qty, 14)
        loaded = build_model(parse_xpdmxml(updated.export.xml_bytes))
        self.assertEqual(loaded.comp('P').total_qty, 18)
        reduced = set_link_quantity(loaded, 'A', 'P', 1)
        self.assertEqual(reduced.comp('P').total_qty, 10)

    def test_new_parent_link(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        updated = set_link_quantity(model, 'R', 'P', 4)
        self.assertEqual(updated.comp('P').total_qty, 18)
        self.assertEqual(updated.comp('P').n_parents, 3)
        self.assertEqual(updated.comp('P').level, 1)

    def test_invalid_links(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        for parent, child, qty in [('A', 'R', 1), ('A', 'A', 1), ('P', 'A', 1), ('A', 'P', 0), ('A', 'P', 1.5)]:
            with self.subTest(parent=parent, child=child, qty=qty), self.assertRaises(ValueError):
                set_link_quantity(model, parent, child, qty)

    def test_xml_validation(self):
        samples = [b'<wrong/>', simple_xml().replace(b'rootRefs="R"', b'rootRefs="MISSING"'),
                   simple_xml().replace(b'<Instancing>P</Instancing>', b'<Instancing>R</Instancing>', 1),
                   simple_xml().replace(b'<Instancing>P</Instancing>', b'<Instancing>MISSING</Instancing>', 1),
                   simple_xml().replace(b'id="A"', b'id="R"', 1)]
        for data in samples:
            with self.subTest(data=data[:60]), self.assertRaises(ValueError):
                parse_xpdmxml(data)
        with self.assertRaises(DefusedXmlException):
            parse_xpdmxml(b'<!DOCTYPE XPDMXML [<!ENTITY x "bad">]><XPDMXML/>')

    def test_geometry_and_original_instances_preserved(self):
        model = self.model
        link = model.bom.iloc[0]
        before = ET.fromstring(model.export.xml_bytes)
        updated = set_link_quantity(model, link.parent, link.child, int(link.qty) + 2)
        after = ET.fromstring(updated.export.xml_bytes)
        by_id = {el.get('id'): el for el in after.iter() if el.get('id')}
        for el in before.iter():
            if el.get('id'):
                self.assertEqual(ET.tostring(el), ET.tostring(by_id[el.get('id')]))
        self.assertEqual(len(updated.export.reps), len(model.export.reps))

    def test_assembly_multiplicity_and_cost_rollup(self):
        model, business = self.model, self.business
        sid = next(model.graph.successors(model.root))
        old = model.graph[model.root][sid]['qty']
        updated = set_link_quantity(model, model.root, sid, old + 2)
        base = cost_lines(model, business)
        result = cost_lines(updated, business)
        local = cost_lines(model, business, scope_id=sid)
        self.assertAlmostEqual(result.line_cost.sum() - base.line_cost.sum(), 2 * local.line_cost.sum() / old)
        self.assertAlmostEqual(unit_rollup(updated, result)[model.root], result.line_cost.sum())

    def test_material_and_country_scenarios(self):
        base = cost_lines(self.model, self.business)
        scenario = Scenario(commodities=[(CU, 30)], tariffs=[('Chine', None, 10)], delays=[('Chine', 4)])
        after = cost_lines(self.model, self.business, scenario).set_index('plm_id')
        for row in base[base.line_type == 'Composant'].itertuples():
            expected = row.purchase_price + (row.material_part * .3 if row.material == CU else 0)
            if row.country == 'Chine':
                expected *= 1.1
            self.assertAlmostEqual(after.loc[row.plm_id, 'purchase_price'], expected)
            self.assertAlmostEqual(after.loc[row.plm_id, 'line_cost'], row.qty * (expected + row.internal_cost))
            self.assertEqual(after.loc[row.plm_id, 'lead_time_weeks'], row.lead_time_weeks + (4 if row.country == 'Chine' else 0))

    def test_shared_part_scoped_forecast(self):
        model = self.model
        tops = list(model.graph.successors(model.root))
        part = next(cid for cid in model.leaves().index if cid in model.descendants(tops[0])
                    and cid not in model.descendants(tops[1]) and model.comp(cid).plm_id in set(self.business.sourcing.plm_id))
        updated = set_link_quantity(model, tops[1], part, 3)
        global_forecast = forecast(updated, self.business, None)
        scoped = [forecast(updated, self.business, None, scope_id=sid) for sid in tops]
        self.assertAlmostEqual(global_forecast['total'].iloc[-1], sum(f['total'].iloc[-1] for f in scoped))
        scenario = Scenario(component_uplift_pct=10, uplift_scope=[updated.comp(tops[1]).short_name])
        global_after = forecast(updated, self.business, scenario)
        scoped_after = [forecast(updated, self.business, scenario, scope_id=sid) for sid in tops]
        self.assertAlmostEqual(global_after['delta_unit'], sum(f['delta_unit'] for f in scoped_after))

    def test_unmapped_import_is_usable(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        self.assertTrue(cost_lines(model, self.business).empty)
        self.assertEqual(len(model.components), 5)

    def test_shared_top_assembly_scoped_quantities(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        # A est à la fois un fils de R et un sous-ensemble de B.
        updated = set_link_quantity(model, 'B', 'A', 3)
        self.assertEqual(updated.comp('P').total_qty, 23)
        self.assertEqual(change_impact(updated, 'P').set_index('xml_id').loc['R', 'instances'], 23)

    def test_invalid_mass(self):
        for value in [b'NaN', b'inf', b'-1']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_xpdmxml(simple_xml().replace(b'_Mass>1<', b'_Mass>' + value + b'<', 1))


if __name__ == '__main__':
    unittest.main()
