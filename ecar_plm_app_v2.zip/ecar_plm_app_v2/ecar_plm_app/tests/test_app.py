"""Parcours Streamlit réels, sans navigateur, via AppTest."""
from pathlib import Path
import unittest

from streamlit.testing.v1 import AppTest

from plm.model import build_model
from plm.parser import parse_xpdmxml
from test_features import simple_xml

ROOT = Path(__file__).resolve().parents[1]


class AppTests(unittest.TestCase):
    def assert_healthy(self, app):
        self.assertEqual([exc.message for exc in app.exception], [])

    def page(self, name):
        app = AppTest.from_string(f'from views import exchange, {name}\nexchange.render()\n{name}.render()', default_timeout=40)
        app.run()
        self.assert_healthy(app)
        return app

    def test_app_navigation_and_structure(self):
        app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=40).run()
        self.assert_healthy(app)

    def test_suppliers(self):
        self.page('suppliers')

    def test_risk_and_scenarios(self):
        app = self.page('risk')
        app.selectbox(key='exposure_material').select('Copper Cu-ETP (enamelled wire)')
        app.number_input(key='exposure_material_pct').set_value(30.0)
        app.selectbox(key='exposure_country').select('Chine')
        app.number_input(key='exposure_country_pct').set_value(10.0)
        app.number_input(key='exposure_delay').set_value(4)
        app.run()
        self.assert_healthy(app)
        app.number_input(key='impact_delta').set_value(5.0).run()
        self.assert_healthy(app)
        app.selectbox(key='exposure_filter_country').select('Chine').run()
        self.assert_healthy(app)
        table = app.dataframe[-1].value
        self.assertTrue((table['Pays'] == 'Chine').all())
        self.assertTrue((table['Retard (sem.)'] == 4).all())
        self.assertGreater(table['Δ / produit (€)'].sum(), 0)


    def test_country_filter_and_usage_ranking(self):
        app = self.page('suppliers')
        self.assertEqual([tab.label for tab in app.tabs][:2], ['Analyse par pays', 'Détail fournisseurs'])
        app.selectbox(key='supply_country').select('Chine').run()
        self.assert_healthy(app)
        detail = next(df.value for df in app.dataframe if 'Parents directs' in df.value.columns)
        self.assertGreater(len(detail), 1)
        self.assertEqual(set(detail['Pays']), {'Chine'})
        self.assertGreater(detail['Fournisseur'].nunique(), 1)
        app = self.page('risk')
        app.selectbox(key='usage_sort').select('Instances père–fils').run()
        self.assert_healthy(app)
        ranking = next(df.value for df in app.dataframe if 'Instances père–fils' in df.value.columns)
        self.assertTrue(ranking['Instances père–fils'].is_monotonic_decreasing)
        app.selectbox(key='usage_kind').select('Pièce').run()
        self.assert_healthy(app)
        ranking = next(df.value for df in app.dataframe if 'Instances père–fils' in df.value.columns)
        self.assertEqual(set(ranking['Type']), {'Pièce'})

    def test_edit_link_and_reset(self):
        app = self.page('risk')
        model = build_model(parse_xpdmxml(ROOT / 'data/XPDMXML_ECAR_PLM.xml'))
        parent = model.root
        child = next(model.graph.successors(parent))
        app.selectbox(key='link_parent').select(parent).run()
        app.selectbox(key=f'link_child_{parent}').select(child).run()
        quantity = next(widget for widget in app.number_input if widget.label == "Nombre d'instances dans le père")
        quantity.set_value(3)
        next(button for button in app.button if button.label == 'Enregistrer le lien et recalculer').click().run()
        self.assert_healthy(app)
        self.assertEqual(app.session_state['_active_model'].graph[parent][child]['qty'], 3)
        self.assertEqual(model.graph[parent][child]['qty'], 1)
        app.button(key='_xml_reset').click().run()
        self.assert_healthy(app)
        self.assertNotIn('_active_model', app.session_state)

    def test_unmapped_import_all_pages(self):
        model = build_model(parse_xpdmxml(simple_xml()))
        for page in ['structure', 'suppliers', 'risk']:
            with self.subTest(page=page):
                app = AppTest.from_string(f'from views import exchange, {page}\nexchange.render()\n{page}.render()', default_timeout=40)
                app.session_state['_active_model'] = model
                app.run()
                self.assert_healthy(app)
                self.assertGreater(len(app.warning), 0)

    def test_single_part_without_mass(self):
        xml = b'<XPDMXML xmlns="http://www.3ds.com/xsd/XPDMXML"><ProductStructure rootRefs="R"><Product id="R"><ID>unknown</ID><Name>Piece seule</Name></Product></ProductStructure></XPDMXML>'
        model = build_model(parse_xpdmxml(xml))
        for page in ['structure', 'risk']:
            with self.subTest(page=page):
                app = AppTest.from_string(f'from views import exchange, {page}\nexchange.render()\n{page}.render()', default_timeout=40)
                app.session_state['_active_model'] = model
                app.run()
                self.assert_healthy(app)

    def test_xml_upload_invalid_then_valid_and_export(self):
        app = self.page('structure')
        if not hasattr(app, 'file_uploader'):
            self.skipTest("La simulation du téléversement exige une version récente de Streamlit.")
        app.file_uploader(key='_xml_upload').set_value(('invalide.xml', b'<wrong/>', 'application/xml'))
        next(button for button in app.button if button.label == 'Importer le XML').click().run()
        self.assert_healthy(app)
        self.assertEqual(len(app.error), 1)
        self.assertNotIn('_active_model', app.session_state)
        app.file_uploader(key='_xml_upload').set_value(('nouveau.xml', simple_xml(), 'application/xml'))
        next(button for button in app.button if button.label == 'Importer le XML').click().run()
        self.assert_healthy(app)
        self.assertEqual(app.session_state['_active_model'].comp('P').total_qty, 14)
        self.assertEqual(app.session_state['_active_model'].export.source_file, 'nouveau.xml')
        self.assertEqual(app.session_state['_active_model'].export.xml_bytes, simple_xml())


if __name__ == '__main__':
    unittest.main()
