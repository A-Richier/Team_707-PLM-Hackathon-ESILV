"""Modèle produit : fusion EI_/3D_, nomenclature avec quantités, graphe, contrôles qualité."""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field

import networkx as nx
import pandas as pd

from .parser import PLMExport


def short_name(name: str) -> str:
    n = re.sub(r"^ECAR[-_ ]?(EI|3D|01)?[_ ]*", "", name).strip(" _")
    n = re.sub(r"^01_", "", n)
    return n.replace("_", " ").strip()


@dataclass
class ProductModel:
    export: PLMExport
    components: pd.DataFrame          # 1 ligne par composant (assemblage ou pièce)
    bom: pd.DataFrame                 # liens composant parent -> enfant avec quantité
    graph: nx.DiGraph                 # parent -> enfant
    root: str
    quality: list = field(default_factory=list)

    # ------------------------------------------------------------------ helpers
    def comp(self, cid: str) -> pd.Series:
        return self.components.loc[cid]

    def children(self, cid: str) -> pd.DataFrame:
        b = self.bom[self.bom.parent == cid]
        return b.merge(self.components, left_on="child", right_index=True)

    def ancestors_path(self, cid: str) -> list[list[str]]:
        """Tous les chemins racine -> composant."""
        return [p for p in nx.all_simple_paths(self.graph, self.root, cid)] if cid != self.root else [[self.root]]

    def where_used(self, cid: str) -> list[str]:
        return list(nx.ancestors(self.graph, cid))

    def descendants(self, cid: str) -> list[str]:
        return list(nx.descendants(self.graph, cid))

    def leaves(self) -> pd.DataFrame:
        return self.components[self.components.kind == "Pièce"]

    def quantities_under(self, cid: str) -> dict[str, int]:
        """Nombre d'instances par référence dans UNE instance du composant."""
        qty = dict.fromkeys(self.graph, 0)
        qty[cid] = 1
        for parent in nx.topological_sort(self.graph):
            for child in self.graph.successors(parent):
                qty[child] += qty[parent] * self.graph[parent][child]["qty"]
        return qty


def build_model(exp: PLMExport) -> ProductModel:
    prods = exp.products.set_index("xml_id")
    inst = exp.instances
    reps_owner = set(exp.reps.owner_product)

    kids: dict[str, list[str]] = defaultdict(list)
    for r in inst.itertuples():
        kids[r.parent].append(r.child)

    def is_geom_leaf(pid: str) -> bool:
        return not kids[pid] and pid in reps_owner

    # Classification
    kind: dict[str, str] = {}
    geom_of: dict[str, str] = {}
    for pid in prods.index:
        ch = kids[pid]
        if not ch:
            continue  # feuilles 3D traitées plus bas
        if len(set(ch)) == 1 and len(ch) == 1 and is_geom_leaf(ch[0]) and pid != exp.root_id:
            kind[pid] = "Pièce"
            geom_of[pid] = ch[0]
        else:
            kind[pid] = "Assemblage"
    # Géométries 3D placées directement dans un assemblage (sans EI_)
    orphan_geom = set()
    for pid in prods.index:
        if pid in kind:
            continue
        parents = set(inst.loc[inst.child == pid, "parent"])
        if any(kind.get(p) == "Assemblage" for p in parents):
            kind[pid] = "Pièce"
            geom_of[pid] = pid
            orphan_geom.add(pid)

    # Un export peut aussi contenir des pièces sans représentation 3D.
    geometry_wrappers = set(geom_of.values()) - orphan_geom
    for pid in prods.index:
        if pid not in kind and pid not in geometry_wrappers and not kids[pid]:
            kind[pid] = "Pièce"
    if exp.root_id not in kind:
        kind[exp.root_id] = "Pièce"

    # Nomenclature au niveau composant
    rows = []
    for (parent, child), grp in inst.groupby(["parent", "child"]):
        if parent in kind and child in kind and kind[parent] == "Assemblage":
            rows.append({
                "parent": parent, "child": child, "qty": len(grp),
                "instance_names": ", ".join(sorted(grp.plm_id)),
                "order": grp.child_order.min(),
            })
    bom = pd.DataFrame(rows, columns=["parent", "child", "qty", "instance_names", "order"]).sort_values("order").reset_index(drop=True)

    g = nx.DiGraph()
    g.add_nodes_from(kind)
    for r in bom.itertuples():
        g.add_edge(r.parent, r.child, qty=r.qty)
    root = exp.root_id

    # Quantité totale, niveau, sous-ensemble
    total_qty: Counter = Counter({root: 1})
    level: dict[str, int] = {root: 0}
    max_level: dict[str, int] = {root: 0}
    subsystems: dict[str, set] = defaultdict(set)
    for node in nx.topological_sort(g):
        if node not in level:
            continue
        for child in g.successors(node):
            total_qty[child] += total_qty[node] * g[node][child]["qty"]
            level[child] = min(level.get(child, float("inf")), level[node] + 1)
            max_level[child] = max(max_level.get(child, 0), max_level[node] + 1)
            subsystems[child].update({child} if node == root else subsystems[node])

    comps = prods.loc[list(kind)].copy()
    comps["mass_kg"] = pd.to_numeric(comps.mass_kg, errors="coerce")
    comps["kind"] = pd.Series(kind)
    comps["geometry_xml_id"] = pd.Series(geom_of)
    comps["has_3d"] = comps.geometry_xml_id.map(lambda x: isinstance(x, str) and x in reps_owner)
    comps["geometry_name"] = comps.geometry_xml_id.map(lambda x: prods.loc[x, "name"] if isinstance(x, str) else None)
    # description : celle de la pièce, sinon celle de sa géométrie
    geo_desc = comps.geometry_xml_id.map(lambda x: prods.loc[x, "description"] if isinstance(x, str) else "")
    comps["description"] = comps.description.where(comps.description != "", geo_desc).fillna("")
    comps["short_name"] = comps.name.map(short_name)
    dup = comps.short_name.duplicated(keep=False)
    comps["label"] = comps.short_name
    comps.loc[dup, "label"] = comps.loc[dup].apply(lambda r: f"{r.short_name} (rév. {r.revision})", axis=1)
    dup2 = comps.label.duplicated(keep=False)
    if dup2.any():
        comps.loc[dup2, "label"] = (comps.loc[dup2, "label"] + " #"
                                    + (comps.loc[dup2].groupby("label").cumcount() + 1).astype(str))
    comps["total_qty"] = pd.Series(total_qty).reindex(comps.index, fill_value=0).astype(int)
    comps["level"] = pd.Series(level).reindex(comps.index, fill_value=-1).astype(int)
    comps["max_level"] = pd.Series(max_level).reindex(comps.index, fill_value=-1).astype(int)
    comps["subsystem_ids"] = [sorted(subsystems[c]) for c in comps.index]
    comps["subsystem_id"] = comps.subsystem_ids.map(lambda ids: ids[0] if ids else "")
    comps["subsystem"] = comps.subsystem_ids.map(lambda ids: " · ".join(comps.loc[x, "short_name"] for x in ids) if ids else "Produit")
    comps["n_parents"] = [g.in_degree(c) for c in comps.index]
    comps["n_children"] = [g.out_degree(c) for c in comps.index]
    comps["orphan_geometry"] = comps.index.isin(orphan_geom)
    comps.index.name = "xml_id"

    model = ProductModel(exp, comps, bom, g, root)
    model.quality = quality_checks(model)
    return model


# ---------------------------------------------------------------------- qualité
def quality_checks(m: ProductModel) -> list[dict]:
    c = m.components
    checks = []

    # 1. cohérence des masses
    bad = []
    for cid in c[c.kind == "Assemblage"].index:
        ch = m.children(cid)
        s = (ch.qty * ch.mass_kg).sum()
        if abs(s - c.loc[cid, "mass_kg"]) > 0.01:
            bad.append(f"{c.loc[cid,'label']} : {c.loc[cid,'mass_kg']:.2f} kg déclarés / {s:.2f} kg calculés")
    checks.append(dict(
        ok=not bad, severity="ok" if not bad else "high",
        title="Cohérence des masses (somme des enfants = parent)",
        detail="Toutes les masses d'assemblage sont cohérentes." if not bad else "; ".join(bad),
        objects=[]))

    # 2. maturité
    n_rel = (c.maturity == "RELEASED").sum()
    checks.append(dict(
        ok=n_rel == len(c), severity="high",
        title="Maturité : aucune pièce diffusée",
        detail=f"{len(c) - n_rel}/{len(c)} composants en {', '.join(sorted(set(c.maturity)))}. "
               "Le produit n'est pas figé : tout chiffrage reste provisoire.",
        objects=[]))

    # 3. homonymes
    d = c[c.short_name.duplicated(keep=False)]
    if len(d):
        checks.append(dict(
            ok=False, severity="medium",
            title=f"{len(d)} composants homonymes",
            detail=f"« {', '.join(sorted(set(d.short_name)))} » : même nom, objets PLM différents "
                   "(RevisionFamily distinctes). Risque de confusion à la commande.",
            objects=list(d.plm_id)))

    # 4. géométrie sans pièce d'ingénierie
    o = c[c.orphan_geometry]
    if len(o):
        checks.append(dict(
            ok=False, severity="medium",
            title="Géométrie 3D placée sans pièce d'ingénierie (EI_)",
            detail=", ".join(o.name) + " : modélisation non homogène avec le reste du produit.",
            objects=list(o.plm_id)))

    # 5. objets de maillage
    mesh = c[c.description.str.contains("single|meshing", case=False, na=False)]
    if len(mesh):
        checks.append(dict(
            ok=False, severity="medium",
            title="Objet de simulation présent dans la nomenclature",
            detail=f"{', '.join(mesh.label)} : « {mesh.description.iloc[0]} ». "
                   "Objet de calcul compté dans la masse du stator.",
            objects=list(mesh.plm_id)))

    # 6. descriptions
    nd = (c.description != "").sum()
    checks.append(dict(
        ok=nd > len(c) * 0.8, severity="low",
        title="Descriptions peu renseignées",
        detail=f"{nd}/{len(c)} composants ont une description.", objects=[]))

    # 7. nomenclature incomplète (rotor)
    names = " ".join(c.name).upper()
    if "ROTOR" not in names:
        checks.append(dict(
            ok=False, severity="high",
            title="Nomenclature moteur incomplète : pas de rotor",
            detail="Aucun rotor ni aimant dans EMOTOR FRONT. Coût et risques matières (terres rares) sous-estimés.",
            objects=[]))

    # 8. noms d'instance anormaux
    weird = m.export.instances[m.export.instances.plm_id.str.contains("Hackathon|KHR", na=False)]
    if len(weird):
        checks.append(dict(
            ok=False, severity="low",
            title="Nom d'instance non conforme",
            detail=", ".join(weird.plm_id), objects=list(weird.plm_id)))

    # 9. géométries partagées
    inst = m.export.instances
    geo_parents = inst.groupby("child").parent.nunique()
    shared = [x for x, n in geo_parents.items() if n > 1 and x not in c.index]
    if shared:
        pn = m.export.products.set_index("xml_id")
        checks.append(dict(
            ok=False, severity="low",
            title="Géométries 3D partagées entre plusieurs pièces",
            detail=", ".join(pn.loc[shared, "name"]) + " : une modification de forme impacte plusieurs pièces.",
            objects=list(pn.loc[shared, "plm_id"])))
    return checks
