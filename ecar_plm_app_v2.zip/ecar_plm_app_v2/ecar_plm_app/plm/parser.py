"""Lecture d'un export XPDMXML (3DEXPERIENCE) en tables pandas.

Trois types d'objets sont lus :
- Product      : références (pièces, assemblages)
- ProductInst  : instances = liens parent (Owned) -> enfant (Instancing)
- Rep3DAggr    : représentations 3D rattachées à un Product (Owned)
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
import math
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
import networkx as nx
from defusedxml import ElementTree as SafeET

NS = {"x": "http://www.3ds.com/xsd/XPDMXML"}
MASS_TAG = "WCGEquivalentComputedExt.V_WCG_Mass"


@dataclass
class PLMExport:
    header: dict
    root_id: str
    products: pd.DataFrame
    instances: pd.DataFrame
    reps: pd.DataFrame
    source_file: str
    xml_bytes: bytes = b""


def _txt(el: ET.Element, tag: str) -> str:
    return (el.findtext(f"x:{tag}", default="", namespaces=NS) or "").strip()


def _common(el: ET.Element) -> dict:
    uid = el.find("x:UniqueID", NS)
    return {
        "xml_id": el.get("id"),
        "plm_id": _txt(el, "ID"),
        "name": _txt(el, "Name"),
        "description": _txt(el, "Description"),
        "xid": uid.get("XID") if uid is not None else "",
        "revision_family": _txt(el, "RevisionFamily"),
        "created": _txt(el, "TimeCreated"),
        "modified": _txt(el, "TimeModified"),
        "owner": _txt(el, "Owner"),
        "organization": _txt(el, "Organization"),
        "project": _txt(el, "Project"),
    }


def parse_xpdmxml(path: str | Path | bytes, source_file: str = "import.xml") -> PLMExport:
    data = path if isinstance(path, bytes) else Path(path).read_bytes()
    if len(data) > 20 * 1024 * 1024:
        raise ValueError("Le fichier XML dépasse la limite de 20 Mo.")
    root = SafeET.fromstring(data, forbid_dtd=True)
    header = {
        i.get("name"): i.get("value")
        for i in root.findall("x:InfoHeader/x:Info", NS)
    }
    ps = root.find("x:ProductStructure", NS)
    if ps is None:
        raise ValueError("Format attendu : XPDMXML 3DEXPERIENCE avec ProductStructure.")
    root_id = ps.get("rootRefs")

    products = []
    for p in ps.findall("x:Product", NS):
        row = _common(p)
        mass = _txt(p, MASS_TAG)
        mass_value = float(mass) if mass else None
        if mass_value is not None and (not math.isfinite(mass_value) or mass_value < 0):
            raise ValueError("Les masses doivent être des nombres finis et positifs ou nuls.")
        row.update(
            revision=_txt(p, "RevisionName"),
            revision_index=int(_txt(p, "RevisionIndex") or 0),
            maturity=_txt(p, "Maturity"),
            lifecycle=_txt(p, "Lifecycle"),
            mass_kg=mass_value,
            material=_txt(p, "Material") or None,
        )
        products.append(row)

    instances = []
    for i in ps.findall("x:ProductInst", NS):
        row = _common(i)
        tr = i.find("x:RelativeTransformation3D", NS)
        t = [float(v) for v in _txt(tr, "Translation3D").split()] if tr is not None else [0, 0, 0]
        if len(t) != 3:
            raise ValueError("Une translation d'instance doit contenir trois coordonnées.")
        row.update(
            parent=_txt(i, "Owned"),
            child=_txt(i, "Instancing"),
            child_order=float(_txt(i, "ChildOrder") or 0),
            tx=t[0], ty=t[1], tz=t[2],
        )
        instances.append(row)

    reps = []
    for r in ps.findall("x:Rep3DAggr", NS):
        row = _common(r)
        row.update(
            revision=_txt(r, "RevisionName"),
            maturity=_txt(r, "Maturity"),
            owner_product=_txt(r, "Owned"),
        )
        reps.append(row)

    ids = [r["xml_id"] for r in products]
    all_ids = [el.get("id") for el in root.iter() if el.get("id") is not None]
    if not products or not all(ids) or len(all_ids) != len(set(all_ids)):
        raise ValueError("Les identifiants XML doivent être présents et uniques.")
    if root_id not in ids:
        raise ValueError("La racine du produit est absente ou multiple.")
    plm_ids = [r["plm_id"] for r in products]
    if not all(plm_ids) or len(plm_ids) != len(set(plm_ids)):
        raise ValueError("Les identifiants PLM des produits doivent être présents et uniques.")
    graph = nx.DiGraph()
    graph.add_nodes_from(ids)
    for r in instances:
        if r["parent"] not in graph or r["child"] not in graph:
            raise ValueError("Un lien père–fils référence un produit absent du fichier.")
        graph.add_edge(r["parent"], r["child"])
    if not nx.is_directed_acyclic_graph(graph):
        raise ValueError("La nomenclature contient un cycle père–fils.")
    if graph.in_degree(root_id):
        raise ValueError("La racine du produit ne peut pas avoir de parent.")
    if any(r["owner_product"] not in graph for r in reps):
        raise ValueError("Une représentation 3D référence un produit absent.")

    return PLMExport(
        header=header,
        root_id=root_id,
        products=pd.DataFrame(products),
        instances=pd.DataFrame(instances, columns=list(instances[0]) if instances else
                               ["xml_id", "plm_id", "parent", "child", "child_order", "tx", "ty", "tz"]),
        reps=pd.DataFrame(reps, columns=list(reps[0]) if reps else ["xml_id", "owner_product"]),
        source_file=source_file if isinstance(path, bytes) else Path(path).name,
        xml_bytes=data,
    )
