"""Dépendances géographiques et réutilisation des références de la nomenclature."""
import networkx as nx
import pandas as pd


UNKNOWN_COUNTRY = "Pays non renseigné"


def component_usage(model):
    """Une ligne par référence active, hors racine ; ancêtres et parents dédupliqués."""
    active = model.components[model.components.total_qty > 0]
    graph = model.graph.subgraph(active.index)
    rows = []
    for cid, part in active.iterrows():
        if cid == model.root:
            continue
        parents = sorted(graph.predecessors(cid), key=lambda n: model.comp(n).label)
        ancestors = nx.ancestors(graph, cid)
        rows.append(dict(xml_id=cid, plm_id=part.plm_id, label=part.label, kind=part.kind,
                         direct_parents=len(parents), ancestors=len(ancestors),
                         link_instances=sum(graph[p][cid]["qty"] for p in parents),
                         total_qty=int(part.total_qty),
                         parents=" · ".join(model.comp(p).label for p in parents)))
    return pd.DataFrame(rows, columns=["xml_id", "plm_id", "label", "kind", "direct_parents",
                                      "ancestors", "link_instances", "total_qty", "parents"])


def country_components(model, lines):
    """Pays des achats connus et pièces sans sourcing ; aucune origine déduite d'un parent."""
    purchased = lines[lines.line_type == "Composant"]
    excluded = set(lines.loc[lines.line_type == "Exclu", "xml_id"])
    active = model.components[model.components.total_qty > 0]
    parts = active[(active.kind == "Pièce") | active.index.isin(purchased.xml_id)]
    parts = parts[~parts.index.isin(excluded)]
    data = parts[["plm_id", "label", "total_qty"]].reset_index().rename(columns={"total_qty": "qty"})
    data = data.merge(purchased[["xml_id", "country", "supplier", "purchase_line", "country_risk"]],
                      on="xml_id", how="left", validate="one_to_one")
    data["country"] = data.country.astype("string").replace(r"^\s*$", pd.NA, regex=True).fillna(UNKNOWN_COUNTRY)
    data["supplier"] = data.supplier.fillna("Non renseigné")
    active_ids = set(active.index)
    data["parent_ids"] = [set(model.graph.predecessors(cid)) & active_ids for cid in data.xml_id]
    data["ancestor_ids"] = [nx.ancestors(model.graph, cid) & active_ids for cid in data.xml_id]
    data["parents"] = data.parent_ids.map(lambda ids: " · ".join(sorted(model.comp(n).label for n in ids)))
    return data


def country_summary(data):
    """Parts calculées sur le produit entier, avant tout filtre d'affichage."""
    rows = []
    total_spend = data.purchase_line.sum()
    for country, group in data.groupby("country", sort=True):
        spend = group.purchase_line.sum(min_count=1)
        rows.append(dict(country=country, references=len(group), instances=int(group.qty.sum()),
                         components=" · ".join(group.sort_values("label").label),
                         purchase_line=spend,
                         purchase_share=100 * spend / total_spend if total_spend > 0 else float("nan"),
                         reference_share=100 * len(group) / len(data),
                         direct_parents=len(set().union(*group.parent_ids)),
                         ancestors=len(set().union(*group.ancestor_ids)),
                         country_risk=group.country_risk.max(),
                         shared_risk="Pays inconnu" if country == UNKNOWN_COUNTRY else (
                             "Exposition commune" if len(group) > 1 else "Une référence")))
    return pd.DataFrame(rows, columns=["country", "references", "instances", "components", "purchase_line",
                                      "purchase_share", "reference_share", "direct_parents", "ancestors",
                                      "country_risk", "shared_risk"]).sort_values(
                                          ["references", "purchase_line", "country"], ascending=[False, False, True])
