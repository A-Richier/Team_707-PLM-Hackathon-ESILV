"""Couche business : coûts, CO2, délais, criticité, scénarios.

Toutes les données business (fournisseurs, prix, pays...) sont SIMULÉES et
rattachées aux composants par leur identifiant PLM (prd-...).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .model import ProductModel

EUROPE = {"Europe"}


@dataclass
class Business:
    params: dict
    countries: pd.DataFrame
    materials: pd.DataFrame
    suppliers: pd.DataFrame
    sourcing: pd.DataFrame
    assembly: pd.DataFrame
    substitutions: pd.DataFrame

    @property
    def price(self) -> float:
        return float(self.params["selling_price_eur"])

    @property
    def volume(self) -> int:
        return int(float(self.params["annual_volume"]))


def load_business(folder: str | Path) -> Business:
    f = Path(folder)
    p = pd.read_csv(f / "business_parameters.csv")
    return Business(
        params=dict(zip(p.key, p.value)),
        countries=pd.read_csv(f / "countries.csv").set_index("country"),
        materials=pd.read_csv(f / "materials.csv").set_index("material"),
        suppliers=pd.read_csv(f / "suppliers.csv").set_index("supplier_id"),
        sourcing=pd.read_csv(f / "sourcing.csv", dtype={"supplier_id": str, "alt_supplier_id": str}),
        assembly=pd.read_csv(f / "assembly_operations.csv"),
        substitutions=pd.read_csv(f / "substitutions.csv"),
    )


# ------------------------------------------------------------------- scénario
@dataclass
class Scenario:
    name: str = "Référence"
    # (pays, matériau ou None, %) : droits de douane / surcoût sur le prix d'achat
    tariffs: list = field(default_factory=list)
    # (matériau, %) : variation du cours matière (s'applique à la part matière)
    commodities: list = field(default_factory=list)
    # (pays, semaines) : allongement des délais
    delays: list = field(default_factory=list)
    # plm_id -> True : bascule vers le fournisseur alternatif
    switch_supplier: dict = field(default_factory=dict)
    # plm_id -> matériau de substitution
    substitute: dict = field(default_factory=dict)
    # hausse (%) saisie par l'utilisateur sur le prix d'achat des composants ; 0 = aucun effet
    component_uplift_pct: float = 0.0
    # sous-ensembles concernés par la hausse (noms courts) ; None = tous les composants
    uplift_scope: list | None = None

    def is_empty(self) -> bool:
        return not (self.tariffs or self.commodities or self.delays or self.switch_supplier or self.substitute
                    or self.component_uplift_pct)


CU = "Copper Cu-ETP (enamelled wire)"
ES = "Electrical steel M235-35A (laminated)"
ALU = ["Aluminium alloy EN AC-AlSi9Cu3(Fe) (HPDC)", "Aluminium alloy EN AC-AlSi10Mg (cast)",
       "Aluminium alloy EN AW-6082-T6"]

# Scénarios rattachés au registre des risques (data/business/risks.csv, colonne scenario)
PRESETS = {
    "cuivre_us": Scenario(name="Droits de douane +20 % sur le cuivre américain",
                          tariffs=[("États-Unis", CU, 20.0)], delays=[("États-Unis", 2)]),
    "cuivre_lme": Scenario(name="Cours du cuivre +30 %", commodities=[(CU, 30.0)]),
    "chine_acier": Scenario(name="Restriction chinoise sur l'acier électrique",
                            commodities=[(ES, 25.0)], tariffs=[("Chine", ES, 15.0)], delays=[("Chine", 10)]),
    "alu": Scenario(name="Cours de l'aluminium +25 %", commodities=[(a, 25.0) for a in ALU]),
    "mer_rouge": Scenario(name="Crise maritime mer Rouge",
                          tariffs=[("Chine", None, 6.0), ("Japon", None, 6.0), ("Inde", None, 6.0)],
                          delays=[("Chine", 4), ("Japon", 4), ("Inde", 4)]),
    "kansai": Scenario(name="Défaillance du fournisseur de roulements",
                       tariffs=[("Japon", "Bearing steel 100Cr6 (AISI 52100)", 12.0)], delays=[("Japon", 16)]),
}


# --------------------------------------------------------------- calcul coûts
def cost_lines(m: ProductModel, b: Business, sc: Scenario | None = None, scope_id: str | None = None) -> pd.DataFrame:
    """Une ligne par composant acheté / fabriqué + une ligne par opération d'assemblage."""
    sc = sc or Scenario()
    comps = m.components.reset_index().set_index("plm_id")
    if scope_id and scope_id != m.root:
        quantities = m.quantities_under(scope_id)
        multiplier = int(m.graph[m.root][scope_id]["qty"]) if m.graph.has_edge(m.root, scope_id) else int(m.comp(scope_id).total_qty)
        comps["total_qty"] = comps.xml_id.map(quantities) * multiplier
    mat = b.materials
    sub = b.substitutions
    rows = []
    scope_qty = {}
    if sc.uplift_scope:
        for sid in m.graph.successors(m.root):
            if m.comp(sid).short_name in sc.uplift_scope:
                for cid, qty in m.quantities_under(sid).items():
                    scope_qty[cid] = scope_qty.get(cid, 0) + qty * m.graph[m.root][sid]["qty"]
    for s in b.sourcing.itertuples():
        if s.plm_id not in comps.index:
            continue
        c = comps.loc[s.plm_id]
        if c.total_qty <= 0:
            continue
        base = dict(
            plm_id=s.plm_id, xml_id=c.xml_id, label=c.label, subsystem=c.subsystem,
            revision=c.revision, maturity=c.maturity, qty=int(c.total_qty),
            make_buy=s.make_buy, material_plm=c.material, mass_plm=c.mass_kg,
        )
        if s.make_buy == "Objet de modélisation":
            rows.append({**base, "line_type": "Exclu", "unit_cost": 0.0, "line_cost": 0.0,
                         "co2_line": 0.0, "material": c.material, "mass": c.mass_kg})
            continue

        if c.material not in mat.index or pd.isna(c.mass_kg):
            continue  # signalé par l'interface comme composant non chiffré

        switched = bool(sc.switch_supplier.get(s.plm_id)) and isinstance(s.alt_supplier_id, str)
        sup_id = s.alt_supplier_id if switched else s.supplier_id
        price = float(s.alt_unit_price_eur if switched else s.unit_price_eur)
        sup = b.suppliers.loc[sup_id]
        ctry = b.countries.loc[sup.country]

        material = c.material
        mass = float(c.mass_kg)
        mrow = mat.loc[material]
        mat_part = min(mass * mrow.price_eur_kg, 0.9 * price)
        conversion = price - mat_part
        co2_kg = mrow.co2_kg_per_kg
        feasibility, sub_note = None, None

        if s.plm_id in sc.substitute:
            st = sub[(sub.material_from == material) & (sub.material_to == sc.substitute[s.plm_id])].iloc[0]
            mass = mass * st.mass_factor
            material = st.material_to
            mat_part = mass * st.price_eur_kg
            co2_kg = st.co2_kg_per_kg
            feasibility, sub_note = st.feasibility, st.note

        # choc matière (sur le matériau d'origine ou de substitution)
        for cm, pct in sc.commodities:
            if cm == material:
                mat_part *= 1 + pct / 100
        unit_price = conversion + mat_part
        # droits de douane / surcoûts pays
        tariff_pct = 0.0
        for cty, cm, pct in sc.tariffs:
            if cty == sup.country and (cm is None or cm == material):
                tariff_pct += pct
        unit_price *= 1 + tariff_pct / 100
        # hausse de prix des composants saisie par l'utilisateur (périmètre optionnel)
        uplift_pct = 0.0
        if sc.component_uplift_pct:
            fraction = 1.0 if sc.uplift_scope is None else scope_qty.get(c.xml_id, 0) / c.total_qty
            if sc.uplift_scope is not None and scope_id and scope_id != m.root:
                # Les périmètres proposés sont les enfants directs du produit.
                fraction = float(m.comp(scope_id).short_name in sc.uplift_scope)
            uplift_pct = float(sc.component_uplift_pct) * fraction
            unit_price *= 1 + uplift_pct / 100
        internal = float(s.internal_conversion_eur or 0)

        lead = float(sup.lead_time_weeks)
        for cty, w in sc.delays:
            if cty == sup.country:
                lead += w

        co2_unit = mass * co2_kg * ctry.grid_factor + mass * ctry.transport_co2_kg_per_kg
        q = base["qty"]
        rows.append({
            **base, "line_type": "Composant",
            "material": material, "mass": mass,
            "supplier_id": sup_id, "supplier": sup["name"], "country": sup.country,
            "region": ctry.region, "country_risk": int(ctry.risk_index),
            "supplier_rating": int(sup.rating), "esg": int(sup.esg_score),
            "switched": switched, "has_alt": isinstance(s.alt_supplier_id, str),
            "alt_supplier": b.suppliers.loc[s.alt_supplier_id, "name"] if isinstance(s.alt_supplier_id, str) else None,
            "material_part": mat_part, "conversion": conversion, "tariff_pct": tariff_pct, "uplift_pct": uplift_pct,
            "purchase_price": unit_price, "internal_cost": internal,
            "unit_cost": unit_price + internal, "line_cost": q * (unit_price + internal),
            "purchase_line": q * unit_price,
            "lead_time_weeks": lead, "co2_unit": co2_unit, "co2_line": q * co2_unit,
            "substitution_feasibility": feasibility, "substitution_note": sub_note,
            "buyer_group": s.buyer_group, "weekly_capacity": float(s.weekly_capacity),
            "alt_supplier_id": s.alt_supplier_id if isinstance(s.alt_supplier_id, str) else None,
        })

    for a in b.assembly.itertuples():
        if a.plm_id not in comps.index:
            continue
        c = comps.loc[a.plm_id]
        if c.total_qty <= 0:
            continue
        rows.append(dict(
            plm_id=a.plm_id, xml_id=c.xml_id, label=f"{c.label} — {a.operation}",
            subsystem=c.subsystem if c.subsystem != "Produit" else "Assemblage final",
            revision=c.revision, maturity=c.maturity, qty=int(c.total_qty), make_buy="Interne",
            line_type="Assemblage", unit_cost=float(a.cost_eur), line_cost=float(a.cost_eur) * c.total_qty,
            internal_cost=float(a.cost_eur), purchase_line=0.0, co2_line=0.0,
            supplier="Interne (France)", country="France", region="Europe",
        ))
    df = pd.DataFrame(rows)
    # Schéma stable, y compris lors de l'import d'un produit sans données achats associées.
    columns = ["plm_id", "xml_id", "label", "subsystem", "qty", "line_type", "unit_cost", "line_cost",
               "co2_line", "purchase_line", "supplier_id", "supplier", "country", "region", "material",
               "mass", "material_part", "conversion", "purchase_price", "lead_time_weeks", "country_risk",
               "has_alt", "switched"]
    for col in columns:
        if col not in df:
            df[col] = pd.Series(index=df.index, dtype="object" if col in
                                {"plm_id", "xml_id", "label", "subsystem", "line_type", "supplier_id",
                                 "supplier", "country", "region", "material"} else "float64")
    for col in ("has_alt", "switched"):
        df[col] = df[col].astype("boolean").fillna(False).astype(bool)
    return df


def summary(lines: pd.DataFrame, b: Business) -> dict:
    act = lines[lines.line_type != "Exclu"]
    comp = act[act.line_type == "Composant"]
    cost = act.line_cost.sum()
    purchases = comp.purchase_line.sum()
    margin = b.price - cost
    non_eu = comp[comp.region != "Europe"].purchase_line.sum()
    return dict(
        unit_cost=cost,
        purchases=purchases,
        internal=cost - purchases,
        margin_unit=margin,
        margin_pct=100 * margin / b.price,
        annual_margin=margin * b.volume,
        annual_cost=cost * b.volume,
        revenue=b.price * b.volume,
        co2=act.co2_line.sum(),
        n_suppliers=comp.supplier_id.nunique(),
        n_countries=comp.country.nunique(),
        non_eu_share=100 * non_eu / purchases if purchases else 0,
        max_lead=comp.lead_time_weeks.max(),
        mass=(comp.qty * comp.mass).sum(),
    )


# ---------------------------------------------------------------- criticité
CRIT_WEIGHTS = {
    "Poids dans le coût": 25,
    "Risque pays": 20,
    "Source unique": 15,
    "Concentration pays": 10,
    "Délai": 15,
    "Matière critique / volatile": 15,
}


def criticality(lines: pd.DataFrame, b: Business) -> pd.DataFrame:
    comp = lines[lines.line_type == "Composant"].copy()
    if comp.empty:
        for col in [*CRIT_WEIGHTS, "criticality", "crit_level", "reasons"]:
            comp[col] = pd.Series(dtype="float64" if col == "criticality" else "object")
        return comp
    total = comp.line_cost.sum()
    share = comp.line_cost / max(total, 1e-12)
    country_share = comp.groupby("country").line_cost.transform("sum") / max(total, 1e-12)
    mats = b.materials
    vol = comp.material.map(lambda x: mats.volatility.get(x, 2))
    crit = comp.material.map(lambda x: bool(mats.critical_raw_material.get(x, False)))
    f = pd.DataFrame(index=comp.index)
    f["Poids dans le coût"] = (share / max(share.max(), 1e-12)).clip(0, 1)
    f["Risque pays"] = (comp.country_risk - 1) / 4
    f["Source unique"] = (~comp.has_alt).astype(float)
    f["Concentration pays"] = (country_share / max(country_share.max(), 1e-12)).clip(0, 1)
    f["Délai"] = (comp.lead_time_weeks / max(comp.lead_time_weeks.max(), 1)).clip(0, 1)
    f["Matière critique / volatile"] = ((vol - 1) / 4) * 0.7 + crit * 0.3
    for k, w in CRIT_WEIGHTS.items():
        comp[k] = f[k] * w
    comp["criticality"] = comp[list(CRIT_WEIGHTS)].sum(axis=1)
    comp["crit_level"] = pd.cut(comp.criticality, [-1, 35, 50, 101], labels=["Faible", "Moyenne", "Élevée"])

    def reasons(r):
        out = []
        if r["Poids dans le coût"] > 12: out.append("poids élevé dans le coût")
        if r.country_risk >= 3: out.append(f"pays à risque ({r.country})")
        if not r.has_alt: out.append("source unique")
        if r["Concentration pays"] > 6: out.append(f"achats concentrés dans un même pays ({r.country})")
        if r.lead_time_weeks >= 10: out.append(f"délai {r.lead_time_weeks:.0f} sem.")
        if r["Matière critique / volatile"] > 9: out.append("matière critique/volatile")
        return " · ".join(out) or "—"
    comp["reasons"] = comp.apply(reasons, axis=1)
    return comp.sort_values("criticality", ascending=False)


# ------------------------------------------------------------ registre risques
def _bucket(share_pct: float) -> int:
    for i, t in enumerate([3, 8, 15, 25], start=1):
        if share_pct < t:
            return i
    return 5


def risk_register(lines: pd.DataFrame, b: Business) -> pd.DataFrame:
    comp = lines[lines.line_type == "Composant"]
    total = comp.purchase_line.sum()
    risks = []
    for cty, g in comp.groupby("country"):
        if cty == "France":
            continue
        sh = 100 * g.purchase_line.sum() / total
        p = int(b.countries.loc[cty, "risk_index"])
        if p >= 2 or sh > 10:
            risks.append(dict(risk=f"Dépendance pays : {cty}", family="Géopolitique",
                              probability=p, impact=_bucket(sh), exposure_pct=sh,
                              detail=f"{len(g)} réf. · {sh:.1f} % des achats"))
    mat_spend = (comp.qty * comp.material_part).groupby(comp.material).sum()
    for mname, v in mat_spend.items():
        mr = b.materials.loc[mname] if mname in b.materials.index else None
        if mr is None or (mr.volatility < 4 and not mr.critical_raw_material):
            continue
        sh = 100 * v / total
        risks.append(dict(risk=f"Prix matière : {mr.short}", family="Matières premières",
                          probability=int(mr.volatility), impact=_bucket(sh * 2), exposure_pct=sh,
                          detail=f"Part matière = {sh:.1f} % des achats"))
    for sid, g in comp.groupby("supplier_id"):
        sh = 100 * g.purchase_line.sum() / total
        if len(g) >= 4 or sh >= 12:
            sup = b.suppliers.loc[sid]
            risks.append(dict(risk=f"Concentration fournisseur : {sup['name']}", family="Fournisseur",
                              probability=max(1, 6 - int(sup.rating)), impact=_bucket(sh),
                              exposure_pct=sh, detail=f"{len(g)} réf. · {sh:.1f} % des achats"))
    single = comp[~comp.has_alt]
    if len(single):
        sh = 100 * single.purchase_line.sum() / total
        risks.append(dict(risk="Pièces en source unique", family="Fournisseur", probability=3,
                          impact=max(2, _bucket(sh)), exposure_pct=sh,
                          detail=", ".join(single.label)))
    df = pd.DataFrame(risks)
    df["score"] = df.probability * df.impact
    return df.sort_values("score", ascending=False).reset_index(drop=True)


def scenario_impacted(base: pd.DataFrame, scen: pd.DataFrame) -> pd.DataFrame:
    """Composants dont le coût ou le délai change entre deux calculs."""
    k = ["plm_id", "label", "subsystem", "qty", "supplier", "country", "material",
         "unit_cost", "line_cost", "lead_time_weeks", "co2_line"]
    a = base[base.line_type == "Composant"][k].set_index("plm_id")
    s = scen[scen.line_type == "Composant"][k].set_index("plm_id")
    d = a.join(s, rsuffix="_sc")
    d["delta_unit"] = d.unit_cost_sc - d.unit_cost
    d["delta_line"] = d.line_cost_sc - d.line_cost
    d["delta_lead"] = d.lead_time_weeks_sc - d.lead_time_weeks
    d["delta_co2"] = d.co2_line_sc - d.co2_line
    d["delta_pct"] = 100 * d.delta_unit / d.unit_cost
    imp = d[(d.delta_unit.abs() > 1e-6) | (d.delta_lead.abs() > 1e-6) | (d.delta_co2.abs() > 1e-6)]
    return imp.sort_values("delta_line", ascending=False).reset_index()
