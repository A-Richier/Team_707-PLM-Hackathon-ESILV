"""Séries de prix matières (simulées) et prévisions « IF » d'un scénario de risque."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .business import PRESETS, Business, Scenario, cost_lines
from .model import ProductModel

# tendance annuelle historique (%) par famille de matériau
TREND = {"Cuivre": 12, "Aluminium": 6, "Acier électrique": 4, "Acier": 2, "Fonte": 2, "Polymère": 1, "Élastomère": 3}
HIST = pd.period_range("2025-11", "2026-10", freq="M")
FCST = pd.period_range("2026-11", "2027-10", freq="M")
MONTHS = HIST.append(FCST)
SHOCK_START = 2  # le choc s'applique à partir du 2e mois de prévision (ramp sur 2 mois)


def price_index(b: Business) -> pd.DataFrame:
    """Indice de prix mensuel par matériau, = 1.0 en octobre 2026 (prix des CSV)."""
    rng = np.random.default_rng(42)
    out = {}
    n_h, n_f = len(HIST), len(FCST)
    for mat, r in b.materials.iterrows():
        tr = TREND.get(r.family, 2) / 100 / 12
        noise = r.volatility * 0.008
        hist = np.cumsum(tr + rng.normal(0, noise, n_h))
        hist = np.exp(hist - hist[-1])
        fc = np.exp(np.cumsum(tr * 0.6 + rng.normal(0, noise * 0.4, n_f)))
        out[mat] = np.concatenate([hist, fc])
    df = pd.DataFrame(out, index=MONTHS.to_timestamp())
    return df


def ramp() -> np.ndarray:
    r = np.zeros(len(MONTHS))
    start = len(HIST) + SHOCK_START - 1
    r[start] = 0.5
    r[start + 1:] = 1.0
    return r


def load_risks(folder) -> pd.DataFrame:
    return pd.read_csv(f"{folder}/risks.csv")


def forecast(m: ProductModel, b: Business, sc: Scenario | None, parts: list[str] | None = None,
             scope_id: str | None = None) -> dict:
    """Coût matière par unité et par mois (base + IF) pour un périmètre de pièces."""
    idx = price_index(b)
    base = cost_lines(m, b, scope_id=scope_id)
    comp = base[base.line_type == "Composant"]
    if parts is not None:
        comp = comp[comp.plm_id.isin(parts)]
    per_mat = {}
    for mat, g in comp.groupby("material"):
        per_mat[mat] = float((g.qty * g.material_part).sum()) * idx[mat].values
    mat_df = pd.DataFrame(per_mat, index=idx.index)
    total = mat_df.sum(axis=1)
    if sc is not None and not sc.is_empty():
        L1 = cost_lines(m, b, sc, scope_id=scope_id)
        c1 = L1[L1.line_type == "Composant"].set_index("plm_id")
        c0 = base[base.line_type == "Composant"].set_index("plm_id")
        ids = comp.plm_id
        delta = float(((c1.loc[ids, "purchase_price"] - c0.loc[ids, "purchase_price"]) * c0.loc[ids, "qty"]).sum())
    else:
        delta = 0.0
    total_if = total + delta * ramp()
    return dict(materials=mat_df, total=total, total_if=total_if, delta_unit=delta, index=idx)


def part_price_series(m, b, pid: str, sc: Scenario | None) -> pd.DataFrame:
    idx = price_index(b)
    base = cost_lines(m, b)
    r = base[base.plm_id == pid].iloc[0]
    price = r.conversion + r.material_part * idx[r.material].values
    d = 0.0
    if sc is not None and not sc.is_empty():
        L1 = cost_lines(m, b, sc)
        d = float(L1[L1.plm_id == pid].iloc[0].purchase_price - r.purchase_price)
    return pd.DataFrame({"Prix": price, "Prix IF": price + d * ramp()}, index=idx.index)
