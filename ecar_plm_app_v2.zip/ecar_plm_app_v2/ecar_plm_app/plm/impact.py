"""Édition des instances XPDMXML et propagation des changements dans la nomenclature."""
from copy import deepcopy
from datetime import datetime, timezone
from uuid import uuid4
import xml.etree.ElementTree as ET

import networkx as nx
import pandas as pd
from defusedxml import ElementTree as SafeET

from .model import ProductModel, build_model
from .parser import NS, parse_xpdmxml


def set_link_quantity(model: ProductModel, parent: str, child: str, quantity: int) -> ProductModel:
    """Fixe le nombre d'instances locales ; conserve les métadonnées des instances existantes."""
    if parent not in model.graph or child not in model.graph:
        raise ValueError("Sélectionner deux composants existants.")
    if model.comp(parent).kind != "Assemblage":
        raise ValueError("Le père doit être un assemblage.")
    if parent == child or child == model.root or nx.has_path(model.graph, child, parent):
        raise ValueError("Ce lien créerait un cycle dans la nomenclature.")
    if isinstance(quantity, bool) or int(quantity) != quantity or not 1 <= quantity <= 10000:
        raise ValueError("La quantité doit être un entier entre 1 et 10 000.")
    root = SafeET.fromstring(model.export.xml_bytes, forbid_dtd=True)
    ps = root.find("x:ProductStructure", NS)
    links = [el for el in ps.findall("x:ProductInst", NS)
             if el.findtext("x:Owned", namespaces=NS) == parent
             and el.findtext("x:Instancing", namespaces=NS) == child]
    for el in links[quantity:]:
        ps.remove(el)
    tag = lambda name: f"{{{NS['x']}}}{name}"
    for _ in range(max(0, quantity - len(links))):
        uid = uuid4().hex.upper()
        el = deepcopy(links[0]) if links else ET.Element(tag("ProductInst"))
        el.set("id", "INST_" + uid)
        values = {"ID": "instance-" + uid, "Name": model.comp(child).label,
                  "Owned": parent, "Instancing": child, "ChildOrder": str(len(ps) + 1),
                  "TimeCreated": datetime.now(timezone.utc).isoformat(),
                  "TimeModified": datetime.now(timezone.utc).isoformat(), "RevisionFamily": uid}
        for name, value in values.items():
            field = el.find("x:" + name, NS)
            if field is None:
                field = ET.SubElement(el, tag(name))
            field.text = value
        unique = el.find("x:UniqueID", NS)
        if unique is not None:
            el.remove(unique)
        ET.SubElement(el, tag("UniqueID"), {"XID": uid, "External": uid, "locationOfControl": "V6"})
        if el.find("x:RelativeTransformation3D", NS) is None:
            tr = ET.SubElement(el, tag("RelativeTransformation3D"))
            ET.SubElement(tr, tag("Rotation3D")).text = "1 0 0 0 1 0 0 0 1"
            ET.SubElement(tr, tag("Translation3D")).text = "0 0 0"
        ps.append(el)
    ET.register_namespace("", NS["x"])
    ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
    data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    return build_model(parse_xpdmxml(data, model.export.source_file))


def change_impact(model: ProductModel, cid: str) -> pd.DataFrame:
    """Quantités et distances vers TOUS les ancêtres, sans dupliquer les références partagées."""
    graph = model.graph
    relevant = nx.ancestors(graph, cid) | {cid}
    qty, depth_min, depth_max = {cid: 1}, {cid: 0}, {cid: 0}
    for node in reversed(list(nx.topological_sort(graph))):
        if node not in relevant or node == cid:
            continue
        children = [c for c in graph.successors(node) if c in relevant]
        qty[node] = sum(graph[node][c]["qty"] * qty[c] for c in children)
        depth_min[node] = 1 + min(depth_min[c] for c in children)
        depth_max[node] = 1 + max(depth_max[c] for c in children)
    return pd.DataFrame([
        dict(xml_id=node, label=model.comp(node).label, plm_id=model.comp(node).plm_id,
             instances=qty[node], parent_instances=int(model.comp(node).total_qty),
             depth_min=depth_min[node], depth_max=depth_max[node])
        for node in relevant
    ]).sort_values(["depth_max", "label"]).reset_index(drop=True)
