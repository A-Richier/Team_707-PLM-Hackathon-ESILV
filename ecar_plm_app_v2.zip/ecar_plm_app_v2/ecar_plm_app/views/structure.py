from html import escape

import streamlit as st
import streamlit.components.v1 as components

from plm.business import cost_lines, criticality
from views.common import AMBER, GREEN, RED, band, big, eur, get_data, kv, panel, setup, uplift_control
from views.tree import mini_tree_html, tree_html


def render():
    setup()
    m, b = get_data()
    L0 = cost_lines(m, b)                      # référence (sans hausse saisie)
    band("Structure produit")
    usc = uplift_control(m, b, "structure")
    L = cost_lines(m, b, usc)                  # avec hausse des composants si saisie
    comp_lines = L[L.line_type == "Composant"].set_index("plm_id")
    cr = criticality(L0, b).set_index("plm_id").criticality
    lines = {k: v for k, v in comp_lines.to_dict("index").items()}
    crit = cr.to_dict()
    comps = m.components
    root = comps.loc[m.root]

    k = st.columns(5)
    k[0].markdown(big("Produit", root.short_name.title().replace("Kw", "kW")), unsafe_allow_html=True)
    k[1].markdown(big("Révision / maturité", f"{root.revision} · {root.maturity}"), unsafe_allow_html=True)
    k[2].markdown(big("Masse", f"{root.mass_kg:.1f} kg".replace(".", ",")), unsafe_allow_html=True)
    k[3].markdown(big("Références / pièces", f"{(comps.kind == 'Pièce').sum()} / {int(m.leaves().total_qty.sum())}"),
                  unsafe_allow_html=True)
    dcost = L.line_cost.sum() - L0.line_cost.sum()
    k[4].markdown(big("Coût de revient", eur(L.line_cost.sum()),
                      (f"{'+' if dcost >= 0 else '−'}{eur(abs(dcost))}" if usc is not None else None)),
                  unsafe_allow_html=True)
    st.write("")

    left, right = st.columns([2.3, 1])
    with left:
        with panel("Nomenclature", "tree"):
            tops = [m.root] + list(m.graph.successors(m.root))
            names = {t: ("Produit complet · " if t == m.root else "") + comps.loc[t, "short_name"] for t in tops}
            start = st.selectbox("Arborescence du produit", tops, format_func=names.get, key="tree_scope")
            components.html(tree_html(m, b, L, crit, start=start, open_depth=2 if start == m.root else 99),
                            height=620, scrolling=True)

    with right:
        with panel("Propriétés", "props"):
            opts = comps[comps.total_qty > 0].sort_values("label")
            labels = list(opts.label)
            sel = st.selectbox("Composant", opts.index, index=labels.index("STATOR Coils") if "STATOR Coils" in labels else 0,
                               format_func=lambda x: comps.loc[x, "label"], label_visibility="collapsed")
            c = comps.loc[sel]
            path = m.ancestors_path(sel)[0]
            st.markdown(f'<div class="muted">{" › ".join(comps.loc[p, "short_name"] for p in path)}</div>',
                        unsafe_allow_html=True)
            rows = [("ID PLM", f'<span class="mono">{c.plm_id}</span>'), ("Nom", escape(c["name"])),
                    ("Type", c.kind), ("Révision", c.revision), ("Maturité", c.maturity),
                    ("Masse", f"{c.mass_kg:.3f} kg"), ("Matériau", c.material or "—"),
                    ("Quantité produit", str(int(c.total_qty))), ("Géométrie 3D", c.geometry_name or "—")]
            rows += [("Parents directs", str(int(c.n_parents))),
                     ("Profondeur min. / max.", f"{c.level} / {c.max_level}")]
            ln = lines.get(c.plm_id)
            if ln is not None:
                rows += [("Fournisseur", f'{ln["supplier"]} ({ln["country"]})'),
                         ("Prix unitaire", eur(ln["unit_cost"], 2)), ("Délai", f'{ln["lead_time_weeks"]:.0f} sem.'),
                         ("Alternative", ln["alt_supplier"] or "Source unique"),
                         ("Criticité", f'{crit.get(c.plm_id, 0):.0f} / 100')]
            st.markdown(kv(rows), unsafe_allow_html=True)
            st.markdown('<div style="font-weight:600;font-size:13.5px;margin:10px 0 4px 0">'
                        'Position dans l\'arborescence</div>' + mini_tree_html(m, b, L, sel), unsafe_allow_html=True)
            if c.description:
                st.markdown(f'<div class="muted" style="margin-top:8px">{escape(c.description)}</div>',
                            unsafe_allow_html=True)

        with panel("Contrôles de l'export", "qc"):
            col = {"high": RED, "medium": AMBER, "low": "#9AA8B8", "ok": GREEN}
            html = ""
            for q in sorted(m.quality, key=lambda q: (q["ok"], {"high": 0, "medium": 1, "low": 2}.get(q["severity"], 3))):
                c_ = col["ok"] if q["ok"] else col[q["severity"]]
                html += f'<div class="check"><span class="dot" style="background:{c_}"></span><span>{q["title"]}</span></div>'
            st.markdown(html, unsafe_allow_html=True)
