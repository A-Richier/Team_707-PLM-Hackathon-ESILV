"""Import/export de la nomenclature active, sans écraser le fichier source."""
from pathlib import Path
import xml.etree.ElementTree as ET

from defusedxml.common import DefusedXmlException
import streamlit as st

from plm.business import cost_lines
from plm.model import build_model
from plm.parser import parse_xpdmxml
from views.common import activate_model, get_data


def render():
    model, business = get_data()
    with st.expander("Import / Export XML"):
        st.caption(f"Fichier actif : {model.export.source_file} · {len(model.components)} références. "
                   "Les modifications restent dans cette session ; exporter le XML pour les conserver.")
        left, right = st.columns([2, 1])
        with left:
            with st.form("_xml_import_form"):
                upload = st.file_uploader("Importer un export XPDMXML (20 Mo maximum)", type=["xml"], key="_xml_upload")
                submitted = st.form_submit_button("Importer le XML")
            if submitted:
                if upload is None:
                    st.warning("Choisir un fichier XML à importer.")
                else:
                    try:
                        candidate = build_model(parse_xpdmxml(upload.getvalue(), upload.name))
                        cost_lines(candidate, business)
                    except (ValueError, KeyError, TypeError, OverflowError, ET.ParseError, DefusedXmlException) as exc:
                        st.error(f"Import refusé : {exc}")
                    else:
                        activate_model(candidate)
                        st.rerun()
        with right:
            st.download_button("Exporter le XML actuel", data=model.export.xml_bytes,
                               file_name=Path(model.export.source_file).stem + "_modifie.xml",
                               mime="application/xml", key="_xml_download")
            if st.button("Revenir au XML d'origine", key="_xml_reset"):
                for key in list(st.session_state):
                    if not key.startswith("_xml_"):
                        del st.session_state[key]
                st.rerun()
            st.caption("L'export conserve les produits, représentations 3D et métadonnées XML. "
                       "Les scénarios de prix restent des simulations ; les données achats sont dans les CSV.")
    known = set(cost_lines(model, business).plm_id)
    missing = model.leaves()
    missing = missing[(missing.total_qty > 0) & ~missing.plm_id.isin(known)]
    if not missing.empty:
        st.warning(f"Chiffrage partiel : {len(missing)} pièce(s) sans données achats, matériau reconnu ou masse. "
                   "Ces pièces restent dans la nomenclature et le graphe d'impact, mais sont exclues des coûts.")
        with st.expander("Pièces non chiffrées"):
            st.dataframe(missing[["label", "plm_id", "material", "mass_kg"]], hide_index=True, width="stretch")
