"""Chargement des données, style « dashboard » et composants visuels partagés."""
from __future__ import annotations

import base64
from pathlib import Path

import pandas as pd
import streamlit as st

from plm.business import Business, Scenario, cost_lines, load_business, summary
from plm.model import ProductModel, build_model
from plm.parser import parse_xpdmxml

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

NAVY = "#0B3D6B"
BLUE = "#0F5A8A"
BLUE2 = "#1C7CC0"
LIGHT = "#5FA8DC"
GREEN = "#3BA55C"
LGREEN = "#8BD17C"
AMBER = "#F2B233"
RED = "#D9363E"
GREY = "#8A97A8"
SEQ = ["#1C7CC0", "#F2B233", "#3BA55C", "#8E5BB5", "#D9363E", "#1FA3A3", "#E57A2E",
       "#5FA8DC", "#C2577A", "#6B8E23", "#7F7F7F", "#3F51B5", "#A0522D", "#00897B"]
PLOT = dict(font=dict(family="Segoe UI, Inter, sans-serif", size=12, color="#22313F"),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            margin=dict(l=8, r=8, t=8, b=8), hoverlabel=dict(bgcolor="white"))


def find_xml() -> Path:
    files = sorted(DATA.glob("*.xml")) or sorted(ROOT.glob("*.xml"))
    if not files:
        st.error("Aucun export XPDMXML trouvé dans le dossier data/.")
        st.stop()
    return files[0]


@st.cache_resource(show_spinner="Chargement de l'export PLM")
def _default_data() -> tuple[ProductModel, Business]:
    return build_model(parse_xpdmxml(find_xml())), load_business(DATA / "business")


def get_data() -> tuple[ProductModel, Business]:
    model, business = _default_data()
    return st.session_state.get("_active_model", model), business


def activate_model(model: ProductModel):
    """Remplace le modèle uniquement pour la session courante et réinitialise les sélections."""
    for key in list(st.session_state):
        if not key.startswith("_xml_"):
            del st.session_state[key]
    st.session_state["_active_model"] = model


# ------------------------------------------------------------------ format
def eur(x: float, dec: int = 0) -> str:
    return f"{x:,.{dec}f} €".replace(",", " ").replace(".", ",")


def keur(x: float, sign: bool = False) -> str:
    s = "+" if sign and x >= 0 else ""
    if abs(x) >= 1e6:
        return f"{s}{x/1e6:,.2f} M€".replace(".", ",")
    return f"{s}{x/1e3:,.0f} k€".replace(",", " ")


def stars(n: int) -> str:
    n = int(n)
    return "★" * n + "☆" * (5 - n)


def logo_uri(name: str, color: str) -> str:
    words = [w for w in name.replace(".", " ").split() if w[0].isalpha()]
    ini = (words[0][0] + (words[1][0] if len(words) > 1 else "")).upper()
    svg = (f"<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64'><rect width='64' height='64' rx='10' "
           f"fill='{color}'/><text x='32' y='41' font-family='Arial' font-size='26' font-weight='700' "
           f"fill='white' text-anchor='middle'>{ini}</text></svg>")
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()


# ------------------------------------------------------------------- style
CSS = f"""
<style>
header[data-testid="stHeader"] {{background:{NAVY};}}
header[data-testid="stHeader"] a, header[data-testid="stHeader"] span, header[data-testid="stHeader"] p {{color:#FFFFFFE6 !important;}}
header[data-testid="stHeader"] button svg {{fill:white; color:white;}}
.block-container {{padding-top:3.6rem; padding-bottom:2rem; max-width:1600px;}}
section[data-testid="stSidebar"] {{display:none;}}
div[data-testid="stToolbarActions"], [data-testid="stAppDeployButton"] {{display:none;}}
.band {{background:{BLUE}; color:white; text-align:center; font-size:22px; font-weight:600; padding:7px 0;
  border-radius:4px; margin:4px 0 10px 0; letter-spacing:.01em;}}
div[class*="st-key-pnl_"] {{background:white; border:1px solid #D7DFE8 !important; border-radius:6px;}}
.ph {{background:{BLUE}; color:white; font-weight:600; font-size:14px; padding:7px 12px;
  margin:-1rem -1rem .7rem -1rem; border-radius:5px 5px 0 0;}}
.kv {{display:grid; grid-template-columns: 1fr auto; gap:3px 14px; font-size:13.5px;}}
.kv .k {{color:#3B4B5C; font-weight:600; white-space:nowrap;}} .kv .v {{text-align:right; color:#22313F;}}
.big-l {{font-size:15px; color:#22313F;}} .big {{font-size:30px; font-weight:400; color:#22313F; line-height:1.15;}}
.delta-up {{color:{RED}; font-weight:600;}} .delta-dn {{color:{GREEN}; font-weight:600;}}
.stars {{color:{AMBER}; letter-spacing:1px;}} .stars-b {{color:{BLUE2}; letter-spacing:1px;}}
.tri {{font-size:18px; letter-spacing:2px;}}
.mono {{font-family: ui-monospace, Consolas, monospace; font-size:12px; color:#53687C;}}
.muted {{color:#6A7B8C; font-size:12.5px;}}
.check {{display:flex; gap:8px; align-items:flex-start; font-size:13px; padding:5px 0; border-bottom:1px solid #EEF2F6;}}
.dot {{width:9px; height:9px; border-radius:50%; margin-top:5px; flex:none;}}
div[data-testid="stTabs"] button p {{font-size:14px;}}
.mtree {{font-size:13px; border:1px solid #E3EAF1; border-radius:5px; padding:6px 8px; background:#FAFCFE;}}
.mt {{display:flex; align-items:baseline; gap:6px; padding-top:2px; padding-bottom:2px; border-bottom:1px solid #F0F3F6;}}
.mt-l {{color:#9AA8B8;}} .mt-n {{flex:1 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}}
.mt-q {{color:{BLUE}; font-weight:600;}} .mt-m {{color:#6A7B8C; font-size:11px;}} .mt-c {{width:78px; text-align:right; font-size:12px;}}
.mt.sel {{background:#E3EDF6; font-weight:700; border-radius:4px;}} .mt-e {{color:#6A7B8C; font-size:12px; padding-top:3px;}}
</style>
"""


def setup():
    st.markdown(CSS, unsafe_allow_html=True)


def band(title: str):
    st.markdown(f'<div class="band">{title}</div>', unsafe_allow_html=True)


def panel(title: str, key: str, height: int | None = None):
    kw = {"height": height} if height else {}
    c = st.container(border=True, key=f"pnl_{key}", **kw)
    c.markdown(f'<div class="ph">{title}</div>', unsafe_allow_html=True)
    return c


def kv(rows: list[tuple[str, str]]) -> str:
    return '<div class="kv">' + "".join(f'<div class="k">{k}</div><div class="v">{v}</div>' for k, v in rows) + "</div>"


def big(label: str, value: str, delta: str | None = None, up_is_bad: bool = True) -> str:
    d = ""
    if delta:
        cls = "delta-up" if delta.startswith("+") == up_is_bad else "delta-dn"
        d = f' <span class="{cls}" style="font-size:16px">{delta}</span>'
    return f'<div class="big-l">{label}</div><div class="big">{value}{d}</div>'


def risk_triangles(score: float) -> str:
    n = max(1, min(5, round(score / 20)))
    col = RED if score >= 50 else (AMBER if score >= 35 else GREEN)
    return f'<span class="tri" style="color:{col}">{"▲" * n}</span><span class="tri" style="color:#D7DFE8">{"▲" * (5 - n)}</span>'


def selected_row(event) -> int | None:
    try:
        rows = event.selection.rows
        return rows[0] if rows else None
    except Exception:
        return None


# --------------------------------------------------- simulation hausse de prix
def uplift_control(m, b, key: str) -> Scenario | None:
    """Saisie « hausse du prix des composants » (en %). 0 = aucun effet. Valeur conservée d'un onglet à l'autre."""
    ss = st.session_state
    tops = sorted({m.components.loc[s_, "short_name"] for s_ in m.graph.successors(m.root)})
    scopes = ["Tous les composants"] + tops

    def save():
        ss["_uplift_pct"] = ss[f"uplift_pct_{key}"]
        ss["_uplift_scope"] = ss[f"uplift_scope_{key}"]

    saved_scope = ss.get("_uplift_scope", scopes[0])
    with panel("Simulation : hausse du prix des composants", f"uplift_{key}"):
        a, c_, d = st.columns([1, 1.2, 2.6])
        pct = a.number_input("Hausse du prix (%)", min_value=-50.0, max_value=300.0, step=1.0, format="%.1f",
                             value=float(ss.get("_uplift_pct", 0.0)), key=f"uplift_pct_{key}", on_change=save,
                             help="0 = aucun changement. S'applique au prix d'achat des composants, "
                                  "pas à l'assemblage interne.")
        scope = c_.selectbox("Périmètre", scopes, index=scopes.index(saved_scope) if saved_scope in scopes else 0,
                             key=f"uplift_scope_{key}", on_change=save)
        sc = None
        if pct:
            sc = Scenario(name=f"Hausse composants {pct:+.1f} %", component_uplift_pct=float(pct),
                          uplift_scope=None if scope == scopes[0] else [scope])
            S0, S1 = summary(cost_lines(m, b), b), summary(cost_lines(m, b, sc), b)
            dc = S1["unit_cost"] - S0["unit_cost"]
            d.markdown(kv([("Coût de revient", f"{eur(S0['unit_cost'])} → {eur(S1['unit_cost'])} "
                                               f"({'+' if dc >= 0 else '−'}{eur(abs(dc), 2)})"),
                           ("Marge", f"{S0['margin_pct']:.1f} % → {S1['margin_pct']:.1f} %".replace(".", ",")),
                           ("Impact annuel", keur(S1["annual_margin"] - S0["annual_margin"], True))]),
                       unsafe_allow_html=True)
        else:
            d.markdown('<div class="muted" style="padding-top:28px">Aucune hausse appliquée : les données de '
                       'référence restent inchangées.</div>', unsafe_allow_html=True)
    return sc
