"""Vue principale des dépendances pays, tous fournisseurs confondus."""
import plotly.graph_objects as go
import streamlit as st

from plm.dependencies import UNKNOWN_COUNTRY, country_components, country_summary
from views.common import AMBER, BLUE2, PLOT


def render(model, lines, key):
    st.subheader("Dépendances par pays")
    st.caption("Pays du site fournisseur renseigné, toutes matières et tous fournisseurs confondus. "
               "Les données achats et pays sont simulées ; il ne s'agit pas d'une origine matière certifiée.")
    parts = country_components(model, lines)
    if parts.empty:
        st.info("Aucun composant à analyser dans ce produit.")
        return
    grouped = country_summary(parts)
    known = grouped[grouped.country != UNKNOWN_COUNTRY]
    a, b, c = st.columns(3)
    a.metric("Pays d'approvisionnement", len(known))
    b.metric("Pays communs à plusieurs composants", int((known.references > 1).sum()))
    c.metric("Références sans pays", int((parts.country == UNKNOWN_COUNTRY).sum()))
    if (parts.country == UNKNOWN_COUNTRY).any():
        st.warning("Les composants sans pays restent visibles. Les parts d'achats couvrent uniquement les achats renseignés.")
    fig = go.Figure(go.Bar(x=grouped.country, y=grouped.references,
                          marker_color=[AMBER if n > 1 and country != UNKNOWN_COUNTRY else BLUE2
                                        for n, country in zip(grouped.references, grouped.country)],
                          hovertemplate="%{x}<br>%{y} références<extra></extra>"))
    fig.update_layout(**PLOT, height=280, yaxis_title="Références de composants", yaxis_dtick=1)
    st.plotly_chart(fig, width="stretch")
    labels = {"country": "Pays", "references": "Références", "instances": "Instances / produit",
              "components": "Composants du même pays", "purchase_line": "Achats / produit (€)",
              "purchase_share": "Part des achats connus (%)", "reference_share": "Part des références (%)",
              "direct_parents": "Parents directs distincts", "ancestors": "Parents impactés (tous niveaux)",
              "country_risk": "Risque pays (1–5)", "shared_risk": "Dépendance"}
    st.dataframe(grouped.rename(columns=labels), hide_index=True, width="stretch")
    st.caption("Plusieurs composants d'un même pays peuvent subir simultanément une rupture, un retard "
               "ou une hausse de prix, même avec des fournisseurs différents. Les parents sont comptés "
               "une seule fois par pays ; les totaux de pays différents peuvent se recouvrir.")
    country = st.selectbox("Détailler un pays", [None] + list(grouped.country),
                           format_func=lambda value: "Tous les pays" if value is None else value,
                           key=f"{key}_country")
    detail = parts if country is None else parts[parts.country == country]
    if country is not None and country != UNKNOWN_COUNTRY and len(detail) > 1:
        st.warning(f"{country} : {len(detail)} références partagent cette dépendance géographique : "
                   + ", ".join(detail.sort_values("label").label) + ".")
    table = detail.sort_values(["country", "label"])[
        ["country", "label", "plm_id", "qty", "parents", "supplier", "purchase_line"]].rename(
            columns={"country": "Pays", "label": "Composant", "plm_id": "ID PLM", "qty": "Instances / produit",
                     "parents": "Parents directs", "supplier": "Fournisseur", "purchase_line": "Achats / produit (€)"})
    st.dataframe(table, hide_index=True, width="stretch")
