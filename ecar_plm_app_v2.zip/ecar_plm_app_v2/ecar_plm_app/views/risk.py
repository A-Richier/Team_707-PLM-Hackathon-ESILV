from dataclasses import replace

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from plm.business import PRESETS, Scenario, cost_lines, criticality, scenario_impacted, summary
from plm.market import HIST, forecast, load_risks, part_price_series
from views import countries, exposure, impact
from views.common import (AMBER, BLUE2, DATA, GREEN, GREY, NAVY, PLOT, RED, SEQ, band, big, eur, get_data, keur, kv,
                          panel, risk_triangles, selected_row, setup, uplift_control)

HEAT = [[0, "#3BA55C"], [0.35, "#3BA55C"], [0.36, "#F2D33A"], [0.6, "#F2D33A"], [0.61, "#D9363E"], [1, "#D9363E"]]


def heatmap(risks: pd.DataFrame):
    z = np.array([[p * i for i in range(1, 6)] for p in range(1, 6)], dtype=float)
    counts = risks.groupby(["probability", "impact"]).size()
    text = [[str(counts.get((p, i), "")) for i in range(1, 6)] for p in range(1, 6)]
    fig = go.Figure(go.Heatmap(z=z, x=list(range(1, 6)), y=list(range(1, 6)), colorscale=HEAT, showscale=False,
                               text=text, texttemplate="%{text}", textfont=dict(size=15, color="#22313F"),
                               xgap=2, ygap=2, hoverinfo="skip"))
    fig.update_layout(**PLOT, height=250,
                      xaxis=dict(title="Impact", tickvals=list(range(1, 6)),
                                 ticktext=["Négligeable", "Mineur", "Modéré", "Majeur", "Sévère"], tickfont=dict(size=10)),
                      yaxis=dict(title="Probabilité", tickvals=list(range(1, 6)),
                                 ticktext=["Rare", "Peu probable", "Possible", "Probable", "Quasi certain"],
                                 tickfont=dict(size=10)))
    return fig


def render():
    setup()
    m, b = get_data()
    base = cost_lines(m, b)
    S0 = summary(base, b)
    comp = base[base.line_type == "Composant"]
    cr = criticality(base, b)
    risks = load_risks(DATA / "business")
    comps = m.components

    band("Analyse coût & risque")
    countries.render(m, base, "risk")
    impact.render_ranking(m)
    impact.render(m, b)
    if comp.empty:
        st.info("Aucune donnée de coût associée à cet export. Les liens et le graphe d'impact restent disponibles ci-dessus.")
        return
    custom = exposure.controls(b, comp)
    usc = uplift_control(m, b, "risk")   # hausse de prix des composants saisie (None si 0 %)
    left, center, right = st.columns([1, 2.4, 1.45])

    # ------------------------------------------------ registre des risques (droite)
    with right:
        with panel("Gestion des risques", "risks"):
            t1, t2 = st.tabs(["Risques", "Synthèse"])
            with t1:
                ev = st.dataframe(risks[["risk_id", "title", "root_cause"]], hide_index=True, width="stretch",
                                  height=300, on_select="rerun", selection_mode="single-row", key="risk_sel",
                                  column_config={"risk_id": st.column_config.TextColumn("ID", width="small"),
                                                 "title": st.column_config.TextColumn("Risque", width="large"),
                                                 "root_cause": "Cause"})
            with t2:
                st.plotly_chart(heatmap(risks), width="stretch", config={"displayModeBar": False})
    ri = selected_row(ev)
    risk = risks.iloc[ri] if ri is not None else None
    sc = PRESETS[risk.scenario] if risk is not None else None
    if not custom.is_empty():
        sc = replace(sc or Scenario(), name=(sc.name + " + " if sc else "") + custom.name,
                     commodities=list(sc.commodities if sc else []) + custom.commodities,
                     tariffs=list(sc.tariffs if sc else []) + custom.tariffs,
                     delays=list(sc.delays if sc else []) + custom.delays)
    if usc is not None:   # la hausse saisie se cumule au scénario du risque (ou s'applique seule)
        sc = replace(sc or Scenario(), name=(sc.name + " + " if sc else "") + usc.name,
                     component_uplift_pct=usc.component_uplift_pct, uplift_scope=usc.uplift_scope)
    with right:
        if sc is not None:
            L1 = cost_lines(m, b, sc)
            S1 = summary(L1, b)
            imp = scenario_impacted(base, L1)
        else:
            imp = pd.DataFrame(columns=["plm_id", "delta_unit"])
        if risk is not None:
            with panel(risk.risk_id, "riskcard"):
                st.markdown(kv([("Risque", risk.title), ("Cause racine", risk.root_cause),
                                ("Probabilité / impact", f"{risk.probability} / {risk.impact}"),
                                ("Responsable", risk.owner),
                                ("Hypothèse saisie", f"Composants {usc.component_uplift_pct:+.1f} %" if usc else "—"),
                                ("Pièces touchées", str(len(imp))),
                                ("Surcoût par unité", eur(S1["unit_cost"] - S0["unit_cost"], 2)),
                                ("Impact annuel", keur(S1["annual_margin"] - S0["annual_margin"])),
                                ("Marge", f"{S0['margin_pct']:.1f} % → {S1['margin_pct']:.1f} %".replace(".", ",")),
                                ("Délai max", f"{S0['max_lead']:.0f} → {S1['max_lead']:.0f} sem.")]),
                            unsafe_allow_html=True)
        elif sc is None:
            st.markdown('<div class="muted">Sélectionner un risque ou saisir une hausse de prix pour calculer la prévision IF.</div>',
                        unsafe_allow_html=True)

    # ------------------------------------------------ périmètre (gauche)
    subs = []
    tot = cr.line_cost.sum()
    subs.append(dict(xml=m.root, Périmètre=comps.loc[m.root, "short_name"],
                     Risque=float((cr.criticality * cr.line_cost).sum() / tot) if tot else 0.0))
    for sid in m.graph.successors(m.root):
        quantities = m.quantities_under(sid)
        g = cr[cr.xml_id.map(quantities).fillna(0) > 0].copy()
        g["line_cost"] = g.unit_cost * g.xml_id.map(quantities) * m.graph[m.root][sid]["qty"]
        subs.append(dict(xml=sid, Périmètre=comps.loc[sid, "short_name"],
                         Risque=float((g.criticality * g.line_cost).sum() / g.line_cost.sum()) if g.line_cost.sum() else 0.0))
    subs = pd.DataFrame(subs)
    with left:
        with panel("Périmètres", "scope"):
            ev2 = st.dataframe(subs[["Périmètre", "Risque"]], hide_index=True, width="stretch", on_select="rerun",
                               selection_mode="single-row", key="scope_sel",
                               column_config={"Risque": st.column_config.NumberColumn("Risque", format="%.0f")})
    si = min(selected_row(ev2) or 0, len(subs) - 1)
    scope = subs.iloc[si]
    if scope.xml == m.root:
        scope_parts = list(comp.plm_id)
    else:
        scope_parts = list(comp[comp.xml_id.isin(m.descendants(scope.xml) + [scope.xml])].plm_id)

    # ------------------------------------------------ centre
    f = forecast(m, b, sc, scope_parts, scope_id=scope.xml)
    v = b.volume
    t = f["total"]
    n_h = len(HIST)
    hist_d = (t.iloc[n_h - 1] - t.iloc[0]) * v
    fc_d = (t.iloc[-1] - t.iloc[n_h - 1]) * v
    if_d = (f["total_if"].iloc[-1] - t.iloc[n_h - 1]) * v
    sc_row = comps.loc[scope.xml]

    with center:
        with panel("Coût matière", "cost"):
            a, b1, b2, b3 = st.columns([1.25, 1, 1, 1])
            with a:
                st.markdown(f'<div style="font-weight:600;font-size:15px">{sc_row.short_name}</div>'
                            f'<div class="mono">{sc_row.plm_id} · rév. {sc_row.revision} · {sc_row.maturity}</div>'
                            f'<div style="margin-top:6px" class="muted">Risque</div>{risk_triangles(scope.Risque)}',
                            unsafe_allow_html=True)
            b1.markdown(big("Évolution 12 mois", keur(hist_d, True)), unsafe_allow_html=True)
            b2.markdown(big("Prévision 12 mois", keur(fc_d, True)), unsafe_allow_html=True)
            b3.markdown(big("Prévision IF 12 mois", keur(if_d, True) if sc is not None else "—"), unsafe_allow_html=True)
            st.markdown('<div class="muted">Coût matière annuel du périmètre (volume contractuel).</div>',
                        unsafe_allow_html=True)

        p1, p2 = st.columns([1, 1.5])
        mats = f["materials"]
        cur = mats.iloc[n_h - 1].sort_values(ascending=False)
        short = b.materials.short.to_dict()
        colors = {k: SEQ[i % len(SEQ)] for i, k in enumerate(cur.index)}
        with p1:
            with panel("Répartition matières", "pie"):
                top = cur.iloc[:6]
                pv = list(top.values) + ([cur.iloc[6:].sum()] if len(cur) > 6 else [])
                pl = [short[k] for k in top.index] + (["Autres"] if len(cur) > 6 else [])
                pc = [colors[k] for k in top.index] + ["#C9D3DF"]
                fig = go.Figure(go.Pie(labels=pl, values=pv, sort=False, hole=0.45,
                                       marker=dict(colors=pc, line=dict(color="white", width=1)),
                                       textinfo="percent", textposition="inside",
                                       hovertemplate="%{label}<br>%{value:.2f} € / unité<extra></extra>"))
                fig.update_layout(**PLOT, height=290, legend=dict(font=dict(size=10), orientation="h", y=-0.05))
                st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
        with p2:
            with panel("Prévision coût matière (€ / unité)", "fc"):
                fig = go.Figure()
                x = list(mats.index)
                fig.add_trace(go.Scatter(x=x, y=t, name="Total", line=dict(color=BLUE2, width=3)))
                if sc is not None:
                    fig.add_trace(go.Scatter(x=x[n_h - 1:], y=f["total_if"][n_h - 1:], name="Total IF",
                                             line=dict(color=RED, width=3, dash="dash")))
                for k in list(cur.index)[:5]:
                    fig.add_trace(go.Scatter(x=x, y=mats[k], name=short[k], line=dict(color=colors[k], width=1.3)))
                today = mats.index[n_h - 1]
                fig.add_shape(type="line", x0=today, x1=today, y0=0, y1=1, yref="paper",
                              line=dict(color=GREY, dash="dot"))
                fig.add_annotation(x=today, y=1, yref="paper", text="aujourd'hui", showarrow=False,
                                   xanchor="left", font=dict(size=10, color=GREY))
                fig.update_layout(**PLOT, height=290, legend=dict(font=dict(size=10)),
                                  yaxis=dict(gridcolor="#E6EBF0"), xaxis=dict(tickfont=dict(size=10), tickformat="%b %y", dtick="M3"))
                st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

    # ------------------------------------------------ pièces les plus impactées
    band("Pièces les plus impactées")
    P = comp[comp.plm_id.isin(scope_parts)].merge(cr[["plm_id", "criticality"]], on="plm_id")
    d = dict(zip(imp.plm_id, imp.delta_unit)) if len(imp) else {}
    P["Δ IF (€)"] = P.plm_id.map(d).fillna(0.0)
    P = P.sort_values(["Δ IF (€)", "criticality"], ascending=False).reset_index(drop=True)
    l2, c2 = st.columns([1, 3.85])
    with l2:
        with panel(f"Pièces ({len(P)})", "parts"):
            ev3 = st.dataframe(P[["label", "Δ IF (€)"]], hide_index=True, width="stretch", height=430,
                               on_select="rerun", selection_mode="single-row", key="part_sel",
                               column_config={"label": "Pièce",
                                              "Δ IF (€)": st.column_config.NumberColumn(format="%+.2f")})
    if P.empty:
        st.info("Aucune pièce chiffrée dans ce périmètre.")
        exposure.render(m, b, base, cost_lines(m, b, sc))
        return
    pi = min(selected_row(ev3) or 0, len(P) - 1)
    p = P.iloc[pi]
    with c2:
        with panel(f"{p.label}  ·  {p.plm_id}", "pdetail"):
            a, bb, c, dd = st.columns([1, 1, 1.05, 1.45])
            with a:
                st.markdown('<div style="font-weight:600;margin-bottom:6px">Approvisionnement</div>' + kv([
                    ("Stratégie", "Fabriqué" if "Fabriqué" in p.make_buy else "Acheté"),
                    ("Groupe acheteur", p.buyer_group), ("Fournisseur contractuel", p.supplier),
                    ("Pays", p.country), ("Fournisseur alternatif", p.alt_supplier or "Aucun"),
                    ("Délai", f"{p.lead_time_weeks:.0f} sem.")]), unsafe_allow_html=True)
            with bb:
                need = v / 47 * p.qty
                st.markdown('<div style="font-weight:600;margin-bottom:6px">Autres</div>' + kv([
                    ("Prix", eur(p.purchase_price, 2)), ("Masse totale", f"{p.mass * p.qty:.2f} kg"),
                    ("Matériau", short.get(p.material, p.material)),
                    ("Besoin / sem.", f"{need:.0f}"), ("Capacité / sem.", f"{p.weekly_capacity:.0f}"),
                    ("Criticité", f"{p.criticality:.0f} / 100")]), unsafe_allow_html=True)
            ser = part_price_series(m, b, p.plm_id, sc)
            with c:
                parts_ = [p.material_part, p.conversion]
                labels = ["Matière", "Transformation"]
                if p["Δ IF (€)"] > 0:
                    parts_.append(p["Δ IF (€)"])
                    labels.append("Surcoût IF")
                fig = go.Figure(go.Pie(labels=labels, values=parts_, hole=0.5, sort=False,
                                       marker=dict(colors=[BLUE2, "#9DB7CC", RED]), textinfo="percent",
                                       hovertemplate="%{label}<br>%{value:.2f} €<extra></extra>"))
                fig.update_layout(**PLOT, height=240, legend=dict(orientation="h", y=-0.1, font=dict(size=10)),
                                  title=dict(text="Décomposition du prix", font=dict(size=12), x=0.02, y=0.98))
                st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
            with dd:
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=ser.index, y=ser["Prix"], name="Prix", line=dict(color=BLUE2, width=2.5)))
                if sc is not None and p["Δ IF (€)"] != 0:
                    fig.add_trace(go.Scatter(x=ser.index[n_h - 1:], y=ser["Prix IF"][n_h - 1:], name="Prix IF",
                                             line=dict(color=RED, width=2.5, dash="dash")))
                today = ser.index[n_h - 1]
                fig.add_shape(type="line", x0=today, x1=today, y0=0, y1=1, yref="paper",
                              line=dict(color=GREY, dash="dot"))
                fig.update_layout(**PLOT, height=240, legend=dict(orientation="h", y=-0.15, font=dict(size=10)),
                                  yaxis=dict(gridcolor="#E6EBF0", ticksuffix=" €"), xaxis=dict(tickformat="%b %y", dtick="M4", tickfont=dict(size=10)),
                                  title=dict(text="Prévision du prix", font=dict(size=12), x=0.02, y=0.98))
                st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

            if sc is not None and p.alt_supplier and p["Δ IF (€)"] != 0:
                from copy import deepcopy
                sw = deepcopy(sc)
                sw.switch_supplier = {p.plm_id: True}
                alt = cost_lines(m, b, sw)
                ar = alt[alt.plm_id == p.plm_id].iloc[0]
                cur_if = p.purchase_price + p["Δ IF (€)"]
                gain = (cur_if - ar.purchase_price) * p.qty * v
                verdict = "Bascule rentable" if gain > 0 else "Bascule plus coûteuse"
                col = GREEN if gain > 0 else AMBER
                st.markdown(
                    f'<div style="border-left:4px solid {col};background:#F6F9FC;padding:8px 12px;margin-top:4px;font-size:13.5px">'
                    f'<b>{verdict}</b> : {p.supplier} {eur(cur_if, 2)} (IF) contre {ar.supplier} '
                    f'{eur(ar.purchase_price, 2)} (IF), soit <b>{keur(gain, True)} / an</b>, délai '
                    f'{p.lead_time_weeks + (imp.set_index("plm_id").delta_lead.get(p.plm_id, 0)):.0f} → {ar.lead_time_weeks:.0f} sem.</div>',
                    unsafe_allow_html=True)

    exposure.render(m, b, base, cost_lines(m, b, sc))
