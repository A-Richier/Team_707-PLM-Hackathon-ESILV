"""Arborescence produit : relations parent → enfant, coûts cumulés, vue locale d'un composant."""
from __future__ import annotations

from html import escape

from views.common import AMBER, BLUE, GREEN, RED


def crit_color(v):
    if v is None:
        return "#C9D3DF"
    return RED if v >= 50 else (AMBER if v >= 35 else GREEN)


def fmt(x: float | None) -> str:
    return "" if x is None else f"{x:,.2f}".replace(",", " ")


def unit_rollup(m, lines) -> dict:
    """Coût d'UNE instance de chaque composant : pièce = coût unitaire, assemblage = Σ(qté × enfant) + opérations."""
    comps = m.components
    unit, ops = {}, {}
    for r in lines.itertuples():
        if r.line_type == "Composant":
            unit[r.plm_id] = r.unit_cost
        elif r.line_type == "Assemblage":
            ops[r.plm_id] = ops.get(r.plm_id, 0.0) + r.line_cost
    memo: dict = {}

    def roll(xml_id):
        if xml_id in memo:
            return memo[xml_id]
        c = comps.loc[xml_id]
        kids = m.bom[m.bom.parent == xml_id]
        if kids.empty:
            v = unit.get(c.plm_id, 0.0)
        else:
            v = sum(k.qty * roll(k.child) for k in kids.itertuples())
            v += ops.get(c.plm_id, 0.0) / max(float(c.total_qty), 1.0)
        memo[xml_id] = v
        return v

    for xml_id in comps.index:
        roll(xml_id)
    return memo


def tree_html(m, b, lines, crit, start: str | None = None, open_depth: int = 2) -> str:
    """Nomenclature dépliable. `start` = nœud racine affiché (produit entier ou un sous-ensemble)."""
    comps = m.components
    mats = b.materials.short.to_dict()
    line_by_plm = lines[lines.line_type == "Composant"].set_index("plm_id").to_dict("index")
    roll = unit_rollup(m, lines)
    start = start or m.root

    def row(xml_id, qty, parent_total):
        c = comps.loc[xml_id]
        ln = line_by_plm.get(c.plm_id)
        cr = crit.get(c.plm_id)
        is_asm = c.kind == "Assemblage"
        sup = "Interne" if is_asm else (ln["supplier"] if ln is not None else "Objet de maillage")
        total = qty * roll[xml_id] if (is_asm or ln is not None) else None
        mat = mats.get(c.material, c.material) if isinstance(c.material, str) else ""
        chip = (f'<span class="chip" style="background:{crit_color(cr)}">{cr:.0f}</span>' if cr is not None
                else '<span class="chip" style="background:transparent"></span>')
        icon = '<span class="ic asm"></span>' if is_asm else f'<span class="ic" style="background:{crit_color(cr)}"></span>'
        kids = m.bom[m.bom.parent == xml_id]
        badge = f'<span class="cnt" title="{len(kids)} enfant(s) direct(s)">{len(kids)}</span>' if is_asm else ""
        share = ""
        if parent_total and total:
            pct = 100 * total / parent_total
            share = (f'<span class="sh" title="{pct:.0f} % du coût du parent">'
                     f'<i style="width:{min(pct, 100):.0f}%"></i></span>')
        return (f'<div class="r">{icon}<span class="n">{escape(c.label)}</span>{badge}'
                f'<span class="q">{"×" + str(qty) if qty > 1 else ""}</span>'
                f'<span class="c rev">{c.revision}</span>'
                f'<span class="c num">{c.mass_kg:.2f}</span>'
                f'<span class="c mat">{escape(mat)}</span>'
                f'<span class="c sup">{escape(sup)}</span>'
                f'<span class="c num{" tot" if is_asm else ""}">{fmt(total)}</span>'
                f'{share}'
                f'<span class="c ch">{chip}</span></div>')

    def branch(xml_id, qty, depth, parent_total):
        kids = m.bom[m.bom.parent == xml_id]
        if kids.empty:
            return f'<div class="leaf">{row(xml_id, qty, parent_total)}</div>'
        here = roll[xml_id]  # les lignes enfants sont exprimées par UNE instance du père
        inner = "".join(branch(k.child, k.qty, depth + 1, here) for k in kids.itertuples())
        return (f'<details {"open" if depth < open_depth else ""}><summary>{row(xml_id, qty, parent_total)}</summary>'
                f'<div class="br">{inner}</div></details>')

    head = ('<div class="tb"><button onclick="document.querySelectorAll(\'details\').forEach(d=>d.open=true)">'
            'Tout déplier</button><button onclick="document.querySelectorAll(\'details\').forEach((d,i)=>d.open=i==0)">'
            'Tout replier</button><span class="lg"><i class="ic asm"></i>assemblage '
            '<i class="ic" style="background:#8A97A8"></i>pièce · pastille = enfants directs · barre = part du coût du parent'
            '</span></div>'
            '<div class="hd"><span class="n" style="padding-left:28px">Composant</span><span class="q"></span>'
            '<span class="c rev">Rév.</span><span class="c num">Masse kg</span><span class="c mat">Matériau</span>'
            '<span class="c sup">Fournisseur</span><span class="c num">Coût €</span><span class="c shh">% parent</span>'
            '<span class="c ch">Crit.</span></div>')
    css = f"""<style>
    body{{font:13px 'Segoe UI',Inter,system-ui,sans-serif;color:#22313F;margin:0;background:#fff}}
    .tb{{display:flex;gap:6px;align-items:center;padding:6px;border-bottom:1px solid #D7DFE8;background:#fff}}
    .tb button{{font:inherit;font-size:12px;border:1px solid #C9D3DF;background:#F3F6F9;border-radius:4px;padding:3px 9px;cursor:pointer;color:#22313F}}
    .tb button:hover{{background:#E3EDF6}} .lg{{margin-left:auto;color:#6A7B8C;font-size:11.5px}}
    .lg .ic{{display:inline-block;margin:0 4px 0 8px;vertical-align:middle}}
    .hd{{display:flex;align-items:center;position:sticky;top:0;background:#F3F6F9;border-bottom:1px solid #D7DFE8;
        font-weight:600;color:#3B4B5C;padding:7px 6px;z-index:2;font-size:12px}}
    .r{{display:flex;align-items:center;padding:5px 6px;border-bottom:1px solid #F0F3F6;}}
    summary{{list-style:none;cursor:pointer}} summary::-webkit-details-marker{{display:none}}
    summary .r:hover,.leaf .r:hover{{background:#EEF5FB}}
    summary .r{{background:#FAFCFE}}
    summary .r::before{{content:'▸';color:{BLUE};width:14px;display:inline-block;transition:transform .15s}}
    details[open]>summary .r::before{{transform:rotate(90deg)}}
    .leaf .r::before{{content:'';width:14px;display:inline-block}}
    .br{{margin-left:14px;border-left:1.5px solid #B9C7D6}}
    .br>details,.br>.leaf{{position:relative}}
    .br>details::before,.br>.leaf::before{{content:'';position:absolute;left:0;top:15px;width:9px;border-top:1.5px solid #B9C7D6;z-index:1}}
    details[open]>summary .n{{font-weight:600}}
    .ic{{width:9px;height:9px;border-radius:50%;margin:0 7px 0 2px;flex:none}}
    .ic.asm{{border-radius:2px;background:{BLUE}}}
    .n{{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
    .cnt{{flex:none;margin:0 6px;min-width:16px;text-align:center;font-size:10.5px;font-weight:700;color:{BLUE};
        background:#E3EDF6;border-radius:8px;padding:0 5px}}
    .q{{width:42px;color:{BLUE};font-weight:600;text-align:right;padding-right:8px}}
    .c{{flex:none;padding:0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
    .rev{{width:34px;text-align:center}} .num{{width:70px;text-align:right}} .mat{{width:150px}}
    .num.tot{{font-weight:700;color:{BLUE}}}
    .sup{{width:170px}} .ch{{width:42px;text-align:center}} .id{{width:150px;color:#6A7B8C;font-size:11.5px}}
    .shh{{width:62px;text-align:center}}
    .sh{{flex:none;width:50px;height:6px;margin:0 6px;background:#E8EEF4;border-radius:3px;overflow:hidden}}
    .sh i{{display:block;height:100%;background:{BLUE}}}
    .chip{{display:inline-block;min-width:26px;padding:1px 4px;border-radius:9px;color:white;font-size:11px;font-weight:700}}
    </style>"""
    return ("<!doctype html><html><head><meta charset='utf-8'>" + css + "</head><body>" + head
            + branch(start, 1, 0, None) + "</body></html>")


def mini_tree_html(m, b, lines, sel: str) -> str:
    """Position d'un composant dans l'arborescence : chemin des parents, composant, enfants directs."""
    comps = m.components
    roll = unit_rollup(m, lines)
    path = m.ancestors_path(sel)[0]
    out = []

    def line(xml_id, depth, qty=1, cls=""):
        c = comps.loc[xml_id]
        mark = "└ " if depth else ""
        q = f' <span class="mt-q">×{qty}</span>' if qty > 1 else ""
        cost = qty * roll[xml_id]
        kind = "assemblage" if c.kind == "Assemblage" else "pièce"
        out.append(f'<div class="mt {cls}" style="padding-left:{depth * 16}px"><span class="mt-l">{mark}</span>'
                   f'<span class="mt-n">{escape(c.label)}</span>{q}'
                   f'<span class="mt-m">{kind}</span><span class="mt-c">{fmt(cost)} €</span></div>')

    for d, xml_id in enumerate(path[:-1]):
        line(xml_id, d)
    sel_qty = 1
    if len(path) > 1:
        sel_qty = int(m.bom[(m.bom.parent == path[-2]) & (m.bom.child == sel)].qty.iloc[0])
    line(sel, len(path) - 1, sel_qty, "sel")
    for k in m.bom[m.bom.parent == sel].itertuples():
        line(k.child, len(path), k.qty)
    if not (m.bom.parent == sel).any():
        out.append(f'<div class="mt-e" style="padding-left:{len(path) * 16}px">aucun enfant : pièce achetée ou fabriquée</div>')
    return '<div class="mtree">' + "".join(out) + "</div>"
