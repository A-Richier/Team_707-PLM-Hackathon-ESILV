"""Liens père–fils et graphe de propagation d'une évolution de composant."""
from html import escape

import networkx as nx
import plotly.graph_objects as go
import streamlit as st

from plm.impact import change_impact, set_link_quantity
from plm.dependencies import component_usage
from views.common import AMBER, BLUE2, NAVY, PLOT, activate_model, eur, keur


def impact_figure(model, cid, impact, max_depth, unit_delta):
    visible = impact[impact.depth_max <= max_depth]
    positions = {}
    for depth, group in visible.groupby("depth_max"):
        for i, node in enumerate(group.xml_id):
            positions[node] = (int(depth), (len(group) - 1) / 2 - i)
    fig = go.Figure()
    for parent, child, data in model.graph.edges(data=True):
        if parent not in positions or child not in positions:
            continue
        x0, y0 = positions[child]
        x1, y1 = positions[parent]
        fig.add_trace(go.Scatter(x=[x0, x1], y=[y0, y1], mode="lines",
                                 line=dict(color="#A6B9CD", width=2), hoverinfo="skip", showlegend=False))
        fig.add_annotation(x=x1, y=y1, ax=x0, ay=y0, xref="x", yref="y", axref="x", ayref="y",
                           text="", showarrow=True, arrowhead=2, arrowsize=1.3, arrowcolor="#A6B9CD", standoff=16)
        fig.add_annotation(x=(x0 + x1) / 2, y=(y0 + y1) / 2, text=f"×{data['qty']}",
                           showarrow=False, bgcolor="white", font=dict(size=12, color=NAVY))
    hover = [f"{escape(row.label)}<br>{row.instances} instance(s) de la pièce par unité de ce composant"
             f"<br>Profondeur : {row.depth_min} à {row.depth_max} lien(s)"
             f"<br>Variation par unité de ce composant : {eur(row.instances * unit_delta, 2)}"
             for row in visible.itertuples()]
    fig.add_trace(go.Scatter(x=[positions[n][0] for n in visible.xml_id],
                             y=[positions[n][1] for n in visible.xml_id], mode="markers+text",
                             marker=dict(size=24, color=[AMBER if n == cid else NAVY if n == model.root else BLUE2
                                                         for n in visible.xml_id]),
                             text=[escape(label) for label in visible.label], textposition="top center",
                             textfont=dict(size=11), hovertext=hover, hovertemplate="%{hovertext}<extra></extra>"))
    fig.update_layout(**PLOT, height=max(340, int(visible.groupby("depth_max").size().max()) * 65 + 100),
                      showlegend=False, xaxis=dict(title="Propagation du changement vers les parents", dtick=1,
                      range=[-0.6, max(visible.depth_max.max(), 1) + 0.7]),
                      yaxis=dict(visible=False), hovermode="closest")
    return fig


def render_ranking(model):
    st.subheader("Composants les plus réutilisés : impact d'une modification")
    data = component_usage(model)
    if data.empty:
        st.info("Aucun lien père–fils dans ce produit.")
        return
    choices = {"Parents directs distincts": "direct_parents", "Instances père–fils": "link_instances",
               "Instances dans le produit": "total_qty", "Parents impactés (tous niveaux)": "ancestors"}
    a, b = st.columns(2)
    order = a.selectbox("Classer les composants par", list(choices), key="usage_sort")
    kind = b.selectbox("Type de composant", ["Tous", "Pièce", "Assemblage"], key="usage_kind")
    if kind != "Tous":
        data = data[data.kind == kind]
    data = data.sort_values([choices[order], "label"], ascending=[False, True])
    st.dataframe(data.drop(columns="xml_id").rename(columns={
        "label": "Composant", "plm_id": "ID PLM", "kind": "Type", "direct_parents": "Parents directs distincts",
        "ancestors": "Parents impactés (tous niveaux)", "link_instances": "Instances père–fils",
        "total_qty": "Instances / produit", "parents": "Parents directs"}), hide_index=True, width="stretch")
    st.caption("Instances père–fils = somme des quantités locales de cette référence dans ses parents directs. "
               "Instances / produit = quantités multipliées le long des branches, puis additionnées. "
               "Les parents impactés incluent tous les ancêtres, sans doublon. Un grand nombre de parents "
               "signale une modification à propager largement, même pour une vis peu coûteuse.")


def render(model, business):
    with st.expander("Liens père–fils et impact d'une évolution"):
        edit_tab, graph_tab = st.tabs(["Ajouter / modifier un lien", "Graphe d'impact"])
        with edit_tab:
            st.caption("La quantité est le nombre d'instances de l'enfant dans UNE instance du père. "
                       "Les quantités se multiplient le long des branches et s'additionnent entre branches.")
            parents = model.components[(model.components.kind == "Assemblage") & (model.components.total_qty > 0)]
            if parents.empty:
                st.info("Ce produit ne contient aucun assemblage pouvant recevoir un enfant.")
            else:
                parent = st.selectbox("Père (assemblage)", list(parents.index),
                                      format_func=lambda n: model.comp(n).label, key="link_parent")
                forbidden = nx.ancestors(model.graph, parent) | {parent, model.root}
                choices = [n for n in model.components.sort_values("label").index if n not in forbidden]
                if choices:
                    child = st.selectbox("Fils (composant)", choices, format_func=lambda n: model.comp(n).label,
                                         key=f"link_child_{parent}")
                    current = int(model.graph[parent][child]["qty"]) if model.graph.has_edge(parent, child) else 0
                    st.caption(f"Quantité actuelle dans ce père : {current} · "
                               f"Instances actuelles dans le produit : {int(model.comp(child).total_qty)}")
                    with st.form(f"link_form_{parent}_{child}_{current}"):
                        qty = st.number_input("Nombre d'instances dans le père", min_value=1, max_value=10000,
                                              value=max(current, 1), step=1)
                        submitted = st.form_submit_button("Enregistrer le lien et recalculer")
                    if submitted:
                        try:
                            updated = set_link_quantity(model, parent, child, int(qty))
                        except ValueError as exc:
                            st.error(str(exc))
                        else:
                            activate_model(updated)
                            st.session_state["_link_notice"] = (
                                f"Lien enregistré : {model.comp(parent).label} → {model.comp(child).label} ×{qty}. "
                                f"L'enfant apparaît maintenant {int(updated.comp(child).total_qty)} fois dans le produit.")
                            st.rerun()
                if "_link_notice" in st.session_state:
                    st.success(st.session_state["_link_notice"])
                links = model.bom.copy()
                links["Père"] = links.parent.map(model.components.label)
                links["Fils"] = links.child.map(model.components.label)
                st.dataframe(links[["Père", "Fils", "qty"]].rename(columns={"qty": "Instances / père"}),
                             hide_index=True, width="stretch")
            st.caption("Les masses déclarées dans le PLM sont conservées. Les contrôles de cohérence "
                       "signalent les écarts après modification. Les nouvelles instances ont la position "
                       "du lien existant, ou l'origine pour un nouveau lien ; le placement CAO reste à définir.")
        with graph_tab:
            active = model.components[model.components.total_qty > 0].sort_values(["kind", "label"], ascending=[False, True])
            cid = st.selectbox("Composant modifié", list(active.index), format_func=lambda n: model.comp(n).label,
                               key="impact_component")
            impact = change_impact(model, cid)
            depth = int(impact.depth_max.max())
            a, b = st.columns(2)
            delta = a.number_input("Variation de coût par instance (€)", value=0.0, step=1.0,
                                   help="Hypothèse de changement appliquée à toutes les instances de cette référence.",
                                   key="impact_delta")
            limit = b.slider("Profondeur affichée (liens vers les parents)", 0, max(depth, 1), depth,
                             key=f"impact_depth_{cid}_{depth}")
            qty = int(model.comp(cid).total_qty)
            metrics = st.columns(4)
            metrics[0].metric("Instances dans le produit", qty)
            metrics[1].metric("Références parentes impactées", len(impact) - 1)
            metrics[2].metric("Impact / produit", eur(delta * qty, 2))
            metrics[3].metric("Impact annuel", keur(delta * qty * business.volume, True))
            st.caption(f"Profondeur maximale : {depth}. Une flèche va de l'enfant modifié vers son père ; "
                       "×N indique la quantité locale. Les niveaux suivent le chemin le plus long. "
                       "Le filtre de profondeur ne change pas les totaux.")
            st.plotly_chart(impact_figure(model, cid, impact, limit, delta), width="stretch")
            table = impact.copy()
            table["Δ coût / unité du parent (€)"] = (table.instances * delta).round(2)
            st.dataframe(table.rename(columns={"label": "Composant concerné", "plm_id": "ID PLM",
                         "instances": "Instances de la référence / unité du parent", "depth_min": "Profondeur min.",
                         "depth_max": "Profondeur max.", "parent_instances": "Instances du parent / produit"})
                         .drop(columns="xml_id"), hide_index=True, width="stretch")
            st.caption("Les niveaux se recouvrent : ne pas additionner les impacts des parents. "
                       "L'impact produit compte chaque instance une seule fois. "
                       "Cette hypothèse n'altère pas les prix de référence.")
