import networkx as nx
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from plm.business import cost_lines
from views import countries
from views.common import (AMBER, BLUE, BLUE2, GREEN, GREY, LGREEN, LIGHT, NAVY, PLOT, RED, SEQ, band, big, eur, get_data,
                          keur, kv, logo_uri, panel, selected_row, setup, stars)


def bar_compare(df, col, sel_id, colors, title_unit):
    d = df.sort_values(col)
    cols = [colors[1] if s == sel_id else colors[0] for s in d.supplier_id]
    fig = go.Figure(go.Bar(x=d.short, y=d[col], marker_color=cols,
                           hovertemplate="%{x}<br>%{y}" + title_unit + "<extra></extra>"))
    fig.update_layout(**PLOT, height=230, xaxis=dict(tickangle=-50, tickfont=dict(size=10)),
                      yaxis=dict(gridcolor="#E6EBF0"))
    return fig


def connections(sup_name, parts: pd.DataFrame):
    g = nx.Graph()
    g.add_node(sup_name, t="s")
    for r in parts.itertuples():
        g.add_node(r.label, t="p")
        g.add_node(r.subsystem, t="a")
        g.add_edge(sup_name, r.label)
        g.add_edge(r.label, r.subsystem)
    pos = nx.spring_layout(g, seed=3, k=0.9)
    ex, ey = [], []
    for u, v in g.edges():
        ex += [pos[u][0], pos[v][0], None]
        ey += [pos[u][1], pos[v][1], None]
    fig = go.Figure(go.Scatter(x=ex, y=ey, mode="lines", line=dict(color="#C9D3DF", width=1), hoverinfo="skip"))
    for t, col, size in [("a", NAVY, 16), ("p", LIGHT, 10), ("s", AMBER, 20)]:
        ns = [n for n, d in g.nodes(data=True) if d["t"] == t]
        fig.add_trace(go.Scatter(x=[pos[n][0] for n in ns], y=[pos[n][1] for n in ns],
                                 mode="markers+text" if t != "p" else "markers",
                                 marker=dict(size=size, color=col, line=dict(color="white", width=1.5)),
                                 text=ns, textposition="bottom center" if t == "s" else "top center", textfont=dict(size=10),
                                 hovertemplate="%{text}<extra></extra>"))
    fig.update_layout(**PLOT, height=250, showlegend=False, xaxis=dict(visible=False), yaxis=dict(visible=False))
    return fig


def render():
    setup()
    m, b = get_data()
    L = cost_lines(m, b)
    band("Analyse pays & approvisionnement")
    country_tab, supplier_tab = st.tabs(["Analyse par pays", "Détail fournisseurs"])
    with country_tab:
        countries.render(m, L, "supply")
    with supplier_tab:
        render_suppliers(m, b, L)


def render_suppliers(m, b, L):
    comp = L[L.line_type == "Composant"].copy()
    if comp.empty:
        band("Fournisseurs")
        st.info("Aucune donnée fournisseur associée aux composants de cet export XML.")
        return
    spend = comp.groupby("supplier_id").agg(achats=("purchase_line", "sum"), refs=("plm_id", "count")).reset_index()
    sup = b.suppliers.reset_index().merge(spend, on="supplier_id", how="left").fillna({"achats": 0, "refs": 0})
    sup = sup[sup.refs > 0].sort_values("achats", ascending=False).reset_index(drop=True)
    sup["logo"] = [logo_uri(n, SEQ[i % len(SEQ)]) for i, n in enumerate(sup.name)]
    sup["note"] = sup.rating.map(stars)
    sup["short"] = sup.name.str.split().str[0]

    band("Fournisseurs")
    left, mid = st.columns([1.3, 2.6])
    with left:
        with panel(f"Fournisseurs ({len(sup)})", "suplist"):
            ev = st.dataframe(sup[["logo", "name", "note"]], hide_index=True, width="stretch",
                              height=36 * (len(sup) + 1) + 4,
                              on_select="rerun", selection_mode="single-row", key="sup_sel",
                              column_config={"logo": st.column_config.ImageColumn("", width="small"),
                                             "name": st.column_config.TextColumn("Fournisseur", width="medium"),
                                             "note": st.column_config.TextColumn("Note", width="small")})
    i = selected_row(ev)
    s = sup.iloc[i if i is not None else 0]
    parts = comp[comp.supplier_id == s.supplier_id]

    with mid:
        a, c = st.columns([1.15, 1])
        with a:
            with panel(s["name"], "info"):
                st.markdown(
                    kv([("Note globale", f'<span class="stars">{stars(s.rating)}</span>'),
                        ("Performance qualité", f'<span class="stars-b">{stars(s.quality_perf)}</span>'),
                        ("Performance coût", f'<span class="stars-b">{stars(s.cost_perf)}</span>'),
                        ("Performance délai", f'<span class="stars-b">{stars(s.time_perf)}</span>'),
                        ("Catégorie", s.category), ("Site", f"{s.city}, {s.country}"),
                        ("Certifications", s.certifications)]), unsafe_allow_html=True)
                st.write("")
                x, y = st.columns(2)
                x.markdown(big("Note ESG", f"{int(s.esg_score)}"), unsafe_allow_html=True)
                y.markdown(big("Temps de réponse moyen (h)", f"{int(s.answer_time_h)}"), unsafe_allow_html=True)
        with c:
            with panel("Connexions produit", "conn"):
                st.plotly_chart(connections(s["short"], parts), width="stretch", config={"displayModeBar": False})
                st.markdown(f'<div class="muted">{len(parts)} référence(s) · {keur(s.achats * b.volume)} d\'achats par an</div>',
                            unsafe_allow_html=True)

        g1, g2 = st.columns(2)
        with g1:
            with panel("Indice ESG des fournisseurs", "esg"):
                st.plotly_chart(bar_compare(sup, "esg_score", s.supplier_id, [LGREEN, "#2E7D32"], ""),
                                width="stretch", config={"displayModeBar": False})
        with g2:
            with panel("Temps de réponse moyen (h)", "ans"):
                st.plotly_chart(bar_compare(sup, "answer_time_h", s.supplier_id, [LIGHT, NAVY], " h"),
                                width="stretch", config={"displayModeBar": False})

        t1, t2, t3, t4 = st.tabs(["Pièces nominées", "Sites", "Contrat & économie", "Durabilité"])
        with t1:
            need = b.volume / 47
            P = pd.DataFrame({
                "Pièce": parts.label, "ID PLM": parts.plm_id, "Groupe acheteur": parts.buyer_group,
                "Stratégie": parts.has_alt.map({True: "Double source", False: "Source unique"}),
                "Coût (€)": parts.purchase_price.round(2), "Qté / unité": parts.qty,
                "Capacité / sem.": parts.weekly_capacity.astype(int),
                "Charge": (100 * need * parts.qty / parts.weekly_capacity).round(0),
            })

            def color(v):
                return f"background-color:{'#F8D7DA' if v >= 90 else '#D4EDDA'};color:{'#A4161A' if v >= 90 else '#1E6B34'};font-weight:600"
            st.dataframe(P.style.map(color, subset=["Charge"]).format({"Charge": "{:.0f} %", "Coût (€)": "{:.2f}"}),
                         hide_index=True, width="stretch")
            st.markdown(f'<div class="muted">Charge = besoin hebdomadaire ({need:.0f} unités/sem.) / capacité allouée.</div>',
                        unsafe_allow_html=True)
        with t2:
            fig = go.Figure(go.Scattergeo(lon=[s.lon], lat=[s.lat], text=[f"{s['name']} — {s.city}"],
                                          mode="markers+text", textposition="top center",
                                          marker=dict(size=14, color=AMBER, line=dict(color=NAVY, width=2))))
            fig.add_trace(go.Scattergeo(lon=[2.35], lat=[46.6], text=["Site d'assemblage"], mode="markers+text",
                                        textposition="bottom center", marker=dict(size=11, color=BLUE, symbol="square")))
            fig.add_trace(go.Scattergeo(lon=[s.lon, 2.35], lat=[s.lat, 46.6], mode="lines",
                                        line=dict(color=BLUE2, width=1.5, dash="dot")))
            fig.update_geos(projection_type="natural earth", showcountries=True, countrycolor="#C9D3DF",
                            landcolor="#F1F4F8", showframe=False, fitbounds="locations")
            fig.update_layout(**PLOT, height=330, showlegend=False)
            st.plotly_chart(fig, width="stretch")
        with t3:
            total = comp.purchase_line.sum()
            st.markdown(kv([
                ("Achats annuels", keur(s.achats * b.volume)), ("Part des achats", f"{100 * s.achats / total:.1f} %"),
                ("Fin de contrat", s.contract_end if isinstance(s.contract_end, str) else "Pas de contrat (fournisseur qualifié)"),
                ("Délai de paiement", f"{int(s.payment_terms_days)} jours"), ("Délai d'approvisionnement", f"{int(s.lead_time_weeks)} semaines"),
                ("Livraison à l'heure", f"{int(s.on_time_delivery_pct)} %")]), unsafe_allow_html=True)
        with t4:
            co2 = parts.co2_line.sum()
            st.markdown(kv([
                ("Note ESG", f"{int(s.esg_score)} / 100"), ("CO₂ des pièces fournies", f"{co2:.1f} kg CO₂e / unité"),
                ("CO₂ annuel", f"{co2 * b.volume / 1000:,.0f} t CO₂e".replace(",", " ")),
                ("Facteur mix électrique du pays", f"{b.countries.loc[s.country, 'grid_factor']:.2f}"),
                ("Transport", b.countries.loc[s.country, "transport_mode"]),
                ("Certifications", s.certifications)]), unsafe_allow_html=True)
