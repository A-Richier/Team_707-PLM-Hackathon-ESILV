"""Simulation des cours matière et mise en évidence des dépendances pays."""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from plm.business import Scenario
from views.common import BLUE2, PLOT, eur, keur


def controls(business, components):
    with st.expander("Fluctuation des prix matières et risques pays"):
        st.caption("Hypothèses de simulation, sans connexion à des cours de marché en direct. "
                   "Le pays est celui du site fournisseur renseigné, pas l'origine certifiée de la matière.")
        a, b, c = st.columns(3)
        materials = sorted(components.material.dropna().unique())
        countries = sorted(components.country.dropna().unique())
        material = a.selectbox("Matériau à simuler", [None] + materials,
                               format_func=lambda x: "Choisir un matériau" if x is None else business.materials.loc[x, "short"],
                               key="exposure_material")
        material_pct = a.number_input("Variation du cours matière (%)", min_value=-100.0, max_value=500.0,
                                      value=0.0, step=5.0, key="exposure_material_pct")
        country = b.selectbox("Pays fournisseur à simuler", [None] + countries,
                              format_func=lambda x: "Choisir un pays" if x is None else x, key="exposure_country")
        country_pct = b.number_input("Variation du prix d'achat dans ce pays (%)", min_value=-100.0,
                                     max_value=500.0, value=0.0, step=5.0, key="exposure_country_pct")
        delay = c.number_input("Retard dans ce pays (semaines)", min_value=0, max_value=104, value=0,
                               key="exposure_delay")
        c.caption("Le cours matière agit sur la part matière de toutes les pièces utilisant ce matériau. "
                  "Le choc pays agit sur toutes les pièces du pays choisi, toutes matières confondues. "
                  "Ces hypothèses se cumulent au risque sélectionné et à la hausse globale.")
        return Scenario(name="Simulation matières / pays",
                        commodities=[(material, material_pct)] if material and material_pct else [],
                        tariffs=[(country, None, country_pct)] if country and country_pct else [],
                        delays=[(country, delay)] if country and delay else [])


def render(model, business, base, scenario_lines):
    st.subheader("Composants exposés aux mêmes pays et matériaux")
    data = base[base.line_type == "Composant"].copy()
    changed = scenario_lines[scenario_lines.line_type == "Composant"].set_index("plm_id")
    data["delta"] = data.plm_id.map(changed.line_cost) - data.line_cost
    data["delay"] = data.plm_id.map(changed.lead_time_weeks) - data.lead_time_weeks
    country = st.selectbox("Afficher les composants d'un même pays", ["Tous les pays"] + sorted(data.country.unique()),
                            key="exposure_filter_country")
    if country != "Tous les pays":
        data = data[data.country == country]
    material = st.selectbox("Filtrer par matériau", ["Tous les matériaux"] + sorted(data.material.unique()),
                             format_func=lambda x: business.materials.short.get(x, x), key="exposure_filter_material")
    if material != "Tous les matériaux":
        data = data[data.material == material]
    if data.empty:
        st.info("Aucun composant dans ce périmètre.")
        return
    grouped = data.groupby("country").agg(references=("plm_id", "nunique"), instances=("qty", "sum"),
                achats=("purchase_line", "sum"), delta=("delta", "sum"), delay=("delay", "max")).reset_index()
    metrics = st.columns(4)
    metrics[0].metric("Références exposées", len(data))
    metrics[1].metric("Instances / produit", int(data.qty.sum()))
    metrics[2].metric("Variation / produit", eur(data.delta.sum(), 2))
    metrics[3].metric("Variation annuelle", keur(data.delta.sum() * business.volume, True))
    fig = go.Figure(go.Bar(x=grouped.country, y=grouped.achats, name="Achats actuels", marker_color=BLUE2))
    fig.add_trace(go.Bar(x=grouped.country, y=grouped.achats + grouped.delta, name="Achats simulés", marker_color="#F2B233"))
    fig.update_layout(**PLOT, height=280, barmode="group", yaxis_title="€ / produit", legend=dict(orientation="h"))
    st.plotly_chart(fig, width="stretch")
    st.dataframe(grouped.rename(columns={"country": "Pays fournisseur", "references": "Références",
                 "instances": "Instances / produit", "achats": "Achats / produit (€)",
                 "delta": "Δ / produit (€)", "delay": "Retard maximal (sem.)"}), hide_index=True, width="stretch")
    table = pd.DataFrame({"Composant": data.label, "ID PLM": data.plm_id, "Pays": data.country,
                          "Fournisseur": data.supplier, "Matériau": data.material.map(business.materials.short),
                          "Instances / produit": data.qty, "Parents concernés": [
                              " · ".join(model.comp(n).label for n in sorted(model.where_used(cid))) for cid in data.xml_id],
                          "Δ / pièce (€)": data.delta / data.qty, "Δ / produit (€)": data.delta,
                          "Δ annuel (€)": data.delta * business.volume, "Retard (sem.)": data.delay})
    st.dataframe(table, hide_index=True, width="stretch")
    st.caption("Une dépendance à un même pays expose toutes les pièces listées à un événement commun. "
               "Le détail inclut aussi les pièces dont le prix ne varie pas dans le scénario actuel.")
